package com.orangecameroon.first_trust;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

import javax.net.ssl.SSLContext;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;

/**
 *
 * @author ndziePatrickJoel - Software Factory - Orange Cameroon
 */
public class API {
    
	public  Registry<ConnectionSocketFactory> getRegistry() throws KeyManagementException, NoSuchAlgorithmException {
	    SSLContext sslContext = SSLContexts.custom().build();
	    SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContext,
	            new String[]{"TLSv1.2"}, null, SSLConnectionSocketFactory.getDefaultHostnameVerifier());
	    return RegistryBuilder.<ConnectionSocketFactory>create()
	            .register("http", PlainConnectionSocketFactory.getSocketFactory())
	            .register("https", sslConnectionSocketFactory)
	            .build();
	}
    
    /**
     * This function take
     * @param username
     * @param password
     * @param targetUrl
     * @return token or null
     * @throws ClientProtocolException
     * @throws IOException
     * @throws NoSuchAlgorithmException 
     * @throws KeyManagementException 
     */
    public String authenticate(String username, String password, String targetUrl) throws ClientProtocolException, IOException, KeyManagementException, NoSuchAlgorithmException
    {
    	PoolingHttpClientConnectionManager clientConnectionManager = new PoolingHttpClientConnectionManager(getRegistry());
        clientConnectionManager.setMaxTotal(100);
        clientConnectionManager.setDefaultMaxPerRoute(20);
        HttpClient client = HttpClients.custom().setConnectionManager(clientConnectionManager).build();
        
        
        HttpPost httpPost = new HttpPost(targetUrl);
        
        String json = "{\"username\":\""+username+"\",\"password\":\""+password+"\"}";
        StringEntity entity = new StringEntity(json);
        httpPost.setEntity(entity);
        httpPost.setHeader("Accept", "application/json");
        httpPost.setHeader("Content-type", "application/json");
     
        CloseableHttpResponse response = (CloseableHttpResponse) client.execute(httpPost);
        
        if(response.getStatusLine().getStatusCode() == 200)
        {
        	String content = EntityUtils.toString(response.getEntity());
        	
        	JsonParser parser = new JsonParser();
        	
        	JsonObject jsonObject = parser.parse(content).getAsJsonObject();
        	
        	java.lang.reflect.Type mapType = new TypeToken<Map<String, Object>>(){}.getType();
        	
        	Gson gson = new Gson();
        	Map<String, Object> mapResponse = gson.fromJson(jsonObject, mapType );
        	
        	return (String) mapResponse.get("token");
        }
        
        else
        {
        	String content = EntityUtils.toString(response.getEntity());
        	JsonParser parser = new JsonParser();
        	JsonObject jsonObject = parser.parse(content).getAsJsonObject();
        	java.lang.reflect.Type mapType = new TypeToken<Map<String, Object>>(){}.getType();
        	
        	Gson gson = new Gson();
        	Map<String, Object> mapResponse = gson.fromJson(jsonObject, mapType );
        	return null;
        }
    }
    
    /**
     * This function take
     * @param username
     * @param password
     * @param targetUrl
     * @return token or null
     * @throws ClientProtocolException
     * @throws IOException
     * @throws NoSuchAlgorithmException 
     * @throws KeyManagementException 
     */
    public int sendSMS(String message, String msisdn, String targetUrl, String token, 
    		String[] bundleExpiredKeys, String[] insufficientCreditKeys) throws ClientProtocolException, IOException, KeyManagementException, NoSuchAlgorithmException
    {

    	PoolingHttpClientConnectionManager clientConnectionManager = new PoolingHttpClientConnectionManager(getRegistry());
        clientConnectionManager.setMaxTotal(100);
        clientConnectionManager.setDefaultMaxPerRoute(20);
        HttpClient client = HttpClients.custom().setConnectionManager(clientConnectionManager).build();
        HttpPost httpPost = new HttpPost(targetUrl);
        
        String json = "{\"messageContent\":\""+message+"\", \"projectName\": \"SCB\",  \"campaignTitle\": \"SCB\", \"recipients\":[\""+msisdn+"\"]}";
        StringEntity entity = new StringEntity(json);
        httpPost.setEntity(entity);
        httpPost.setHeader("Accept", "application/json");
        httpPost.setHeader("Content-type", "application/json");
        httpPost.setHeader("Authorization", "Bearer "+token);
     
        CloseableHttpResponse response = (CloseableHttpResponse) client.execute(httpPost);
        
        
        if(response.getStatusLine().getStatusCode() == 201 || response.getStatusLine().getStatusCode() == 200)
        {
        	return 1;
        }
        
        else
        {
        	String content = EntityUtils.toString(response.getEntity()).trim();  
        	        	
        	if(this.stringContainsItemFromList(content, bundleExpiredKeys))
        	{
        		return 3;
        	}
        	
        	if(this.stringContainsItemFromList(content, insufficientCreditKeys))
        	{
        		return 2;
        	}
        	
        	return 0;
        }
    }
    
    
    public boolean stringContainsItemFromList(String inputStr, String[] items)
    {
    	
    	
        for(int i =0; i < items.length; i++)
        {
            if(!inputStr.contains(items[i]))
            {
                return false;
            }
        }
        
        return true;
    }
    
   
}
