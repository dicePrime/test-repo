package com.orangecameroon.first_trust;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import static java.nio.charset.StandardCharsets.ISO_8859_1;
import static java.nio.charset.StandardCharsets.UTF_8;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;


/**
 *
 * @author ndziePatrickJoel - Software Factory - Orange Cameroon
 */
public class Util {
    
    
    public int countLines(String filename) throws IOException 
    {
        LineNumberReader reader = new LineNumberReader(new FileReader(filename));
        int cnt = 0;
        while ((reader.readLine()) != null) {
        }

        cnt = reader.getLineNumber();
        reader.close();
        return cnt;
    }

    public File[] getListOfFilesFromFolder(String path) {
        File folder = new File(path);
        File[] listOfFiles = folder.listFiles();
        
        return listOfFiles;
    }
    
    
    public void writeMessage(int level, String message)
    {
    	StringBuffer strBf = new StringBuffer();

    	
    	for(int i = 0; i < level; i++)
    	{
    		strBf.append(" ");
    	}

    	System.out.println(new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss").format(new Date()) + "::"+strBf.toString() +message);

    }
    
   
    
    public String getFileExtension(File file) {
        String name = file.getName();
        try {
            return name.substring(name.lastIndexOf(".") + 1);
        } catch (Exception e) {
            return "";
        }
    }
}
