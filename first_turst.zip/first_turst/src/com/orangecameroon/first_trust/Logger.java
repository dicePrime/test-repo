package com.orangecameroon.first_trust;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 * This function is responsible of writing in
 * log files
 * @author BMHB8456
 */
public class Logger {
    
}
