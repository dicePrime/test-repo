/**
 * 
 */
package com.orangecameroon.entity;

import javax.servlet.http.HttpServletRequest;

/**
 * @author ndziePatrickJoel/joelpatrickndzie@gmail.com
 * 
 * This class represent a one shot SMS it contains all elements needed to send
 * one sms to the api
 *
 */
public class OneShotSMS {
	
	
	private String msisdn;
	private String message;
	private String username;
	private String password;
	
	public OneShotSMS(HttpServletRequest request)
	{
		this.msisdn = request.getParameter("msisdn");
		this.username = request.getParameter("username");
		this.password = request.getParameter("password");
		this.msisdn = request.getParameter("msisdn");
		this.message = request.getParameter("msg");	
	}
	
	
	
	public String toString()
	{
		StringBuilder stb = new StringBuilder();
		stb.append(this.msisdn);
		stb.append(System.getProperty("line.separator"));
		stb.append(this.username);
		stb.append(System.getProperty("line.separator"));
		stb.append(this.password);
		stb.append(System.getProperty("line.separator"));
		stb.append(this.message);
		return stb.toString();
		
	}
	
	/**
	 * 
	 * This method returns a boolean 
	 * @return boolean
	 */
	public boolean isCompliant()
	{
		if(null == this.msisdn || null == this.username || null == this.password || null == message)
		{
			return false;
		}
		
		return false;
		
	}



	public String getMsisdn() {
		return msisdn;
	}



	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}



	public String getMessage() {
		return message;
	}



	public void setMessage(String message) {
		this.message = message;
	}



	public String getUsername() {
		return username;
	}



	public void setUsername(String username) {
		this.username = username;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
