package com.orangecameroon.first_trust;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.orangecameroon.entity.OneShotSMS;


/**
 * Servlet implementation class Statistiques
 */
@WebServlet("/statistiques")
public class Statistiques extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private ConfigLoader config;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Statistiques() {
        super();
        // TODO Auto-generated constructor stub
        
        try {
			this.config = new ConfigLoader();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			this.config = null;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		if(request.getSession().getAttribute("isConnected") == null)
		{
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
		
		else
		{
			List<OneShotSMS> smsList;
			
			try
			{
				smsList = this.loadSMSLOG();
			}
			catch(Exception e)
			{
				smsList = new ArrayList<OneShotSMS>();
			}
			
			request.setAttribute("smsList", smsList);
			request.getRequestDispatcher("statistiques.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	
	private List<OneShotSMS> loadSMSLOG() throws IOException
	{
		
		List<OneShotSMS> list = new ArrayList<OneShotSMS>();
		
		String webInfPath = getServletConfig().getServletContext().getRealPath("WEB-INF");
		
		String filePath = webInfPath + File.separator + "classes"+ File.separator+"sms.log"; 
		
		File file = new File(filePath);
		
		FileReader fileReader = new FileReader(file);
		
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		
		String line;
		while ((line = bufferedReader.readLine()) != null) {
			
			OneShotSMS tmpSMS = new OneShotSMS(line);
			
			if(tmpSMS.getMessage() == null || tmpSMS.getMsisdn() == null)
			{
				continue;
			}
			
			list.add(tmpSMS);
		}
		
		fileReader.close();
		
		return list;
	}

}
