package com.orangecameroon.first_trust;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Settings
 */
@WebServlet("/settings")
public class Settings extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	private ConfigLoader config;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Settings() {
        super();
        // TODO Auto-generated constructor stub
        try {
			this.config = new ConfigLoader();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			this.config = null;
			e.printStackTrace();
		}
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		if(request.getSession().getAttribute("isConnected") == null)
		{
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
		
		else
		{
			// TODO Auto-generated method stub
			this.config = new ConfigLoader();
			request.setAttribute("username", this.config.getPropertyValue("username").toString());
			request.setAttribute("password", this.config.getPropertyValue("password").toString());
			request.setAttribute("format", this.config.getPropertyValue("response_format").toString());
			request.getRequestDispatcher("settings.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		if(request.getSession().getAttribute("isConnected") == null)
		{
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
		
		this.config = new ConfigLoader();
		
		String old_username = this.config.getPropertyValue("username").toString();
		String old_password = this.config.getPropertyValue("password").toString();
		String old_format = this.config.getPropertyValue("response_format").toString();		
		
		String post_password = request.getParameter("password").toString();
		String post_username = request.getParameter("username").toString();
		String post_format = request.getParameter("response_format").toString();
		
		if( !old_username.equals(post_username) || !old_password.equals(post_password) || !old_format.equals(post_format))
		{
			API api = new API();
			String token;
			try {
				token = api.authenticate(post_username, post_password, 
						this.config.getPropertyValue("url_publique_authentique"));
			} catch (KeyManagementException | NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				token = null;
				e.printStackTrace();
				this.config = new ConfigLoader();
				doGet(request, response);
			}
			
			if(token == null)
			{
				request.setAttribute("error", true);
				this.config = new ConfigLoader();
				doGet(request, response);
			}
			
			String webInfPath = getServletConfig().getServletContext().getRealPath("WEB-INF");
			config.setPropertyValue("password", post_password, webInfPath);
			config.setPropertyValue("username", post_username, webInfPath);
			config.setPropertyValue("response_format", post_format, webInfPath);
			this.config = new ConfigLoader();
		}
		
		doGet(request, response);
	}

}
