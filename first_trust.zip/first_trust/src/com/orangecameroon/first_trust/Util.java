package com.orangecameroon.first_trust;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import static java.nio.charset.StandardCharsets.ISO_8859_1;
import static java.nio.charset.StandardCharsets.UTF_8;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.RandomAccessFile;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;


/**
 *
 * @author ndziePatrickJoel - Software Factory - Orange Cameroon
 */
public class Util {
    
    
    public int countLines(String filename) throws IOException 
    {
        LineNumberReader reader = new LineNumberReader(new FileReader(filename));
        int cnt = 0;
        while ((reader.readLine()) != null) {
        }

        cnt = reader.getLineNumber();
        reader.close();
        return cnt;
    }

    public File[] getListOfFilesFromFolder(String path) {
        File folder = new File(path);
        File[] listOfFiles = folder.listFiles();
        
        return listOfFiles;
    }
    
    public void removeFileLastLine(String fileName) throws IOException
    {
    	RandomAccessFile f = new RandomAccessFile(fileName, "rw");
    	long length = f.length() - 1;
    	byte b;
		do {                     
    	  length -= 1;
    	  f.seek(length);
    	  b = f.readByte();
    	} while(b != 10 && length > 0);
    	f.setLength(length+1);
    	f.close();
    }
    
    
    public void writeMessage(int level, String message)
    {
    	StringBuffer strBf = new StringBuffer();

    	
    	for(int i = 0; i < level; i++)
    	{
    		strBf.append(" ");
    	}

    	System.out.println(new SimpleDateFormat("yyyy:MM:dd:HH:mm:ss").format(new Date()) + "::"+strBf.toString() +message);

    }
    
    public void writeInLogFile(String line, String filePath)
    {
    	String newLine = (new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date())).toString() + ";"+line+"\n";
    	
    	
    	try {
			Files.write(Paths.get(filePath), newLine.getBytes(), StandardOpenOption.APPEND);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
   
    
    public String getFileExtension(File file) {
        String name = file.getName();
        try {
            return name.substring(name.lastIndexOf(".") + 1);
        } catch (Exception e) {
            return "";
        }
    }
}
