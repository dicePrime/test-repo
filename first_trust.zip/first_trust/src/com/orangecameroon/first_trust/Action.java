package com.orangecameroon.first_trust;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.orangecameroon.entity.OneShotSMS;
import com.orangecameroon.entity.SMSResponse;

/**
 * Servlet implementation class Action
 */
@WebServlet(name = "action", urlPatterns = { "/action" })
public class Action extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static int MAX_NUMBER_OF_LINES = 3000;
	
	private ConfigLoader config;
	private Util util;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Action() {
        super();
        // TODO Auto-generated constructor stub
        this.util = new Util();
        try {
			this.config = new ConfigLoader();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			this.config = null;
			e.printStackTrace();
		}
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		OneShotSMS sms = new OneShotSMS(request);
		
		String executionResult = null, executionMessage = null; 
		
		API api = new API();
		
		int resultExecution = 0;
		String resultExecutionString = "FAILED_NETWORK_ISSUE";
		
		try {
			
			String token = api.authenticate(this.config.getPropertyValue("username"), 
					this.config.getPropertyValue("password"), this.config.getPropertyValue("url_publique_authentique").toString());
			
			if (token != null)
			{
				resultExecution = api.sendSMS(sms.getMessage(), 
						sms.getMsisdn(), 
						this.config.getPropertyValue("url_publique_send_sms"), 
						token, 
						this.config.getPropertyValue("bundle_expired_message").trim().split("\\,"), 
						this.config.getPropertyValue("no_more_credit_message").trim().split("\\,"));
				
				switch(resultExecution)
				{
				case 0: 
					executionResult = "nok";
					executionMessage = "network issue";
					resultExecutionString = "FAILED_NETWORK_ISSUE";
					break;
				case 1:
					executionResult = "ok";
					executionMessage = "";
					resultExecutionString = "MESSAGE_SENT_SUCCESSFULLY";
					break;
				case 2:
					executionResult = "nok";
					executionMessage = "insufficient credit";
					resultExecutionString = "FAILED_INSUFFICIENT_CREDIT";
					break;
				case 3:
					executionResult = "nok";
					executionMessage ="bundle expired";
					resultExecutionString = "FAILED_BUNDLE_EXPIRED";
					break;
				}
			}
			
			else
			{
				executionResult = "nok";
				executionMessage = "Invalid credentials";
			}
			
			this.writeSMSInLog(sms, executionResult, executionMessage);
			
		} catch (KeyManagementException   | NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			this.writeSMSInLog(sms, "nok", e.getMessage());
		}
		
		String responseFormat = this.config.getPropertyValue("response_format").toString();
		
		if(responseFormat.equals("html"))
		{
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
		    out.print("<html>");
		    out.print("<head>");
		    out.print("<title>Hola</title>");
		    out.print("</head>");
		    out.print("<body>");
		    out.print(resultExecutionString);
		    out.print("</body>");
		    out.print("</html>");
		}
		
		else if(responseFormat.equals("json"))
		{
			Gson gson = new Gson();
			
			PrintWriter out = response.getWriter();
			
			// setting the response type
			response.setContentType("application/json");
			out.println(gson.toJson(new SMSResponse(resultExecution, executionMessage)));
			out.close();
			
		}
		else
		{
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	private void writeSMSInLog(OneShotSMS sms, String executionResult, String executionMessage)
	{
		String webInfPath = getServletConfig().getServletContext().getRealPath("WEB-INF");
		
		String filePath = webInfPath + File.separator + "classes"+ File.separator+"sms.log";
		
		try {
			int numberOfLines = this.util.countLines(filePath);
			
			if(numberOfLines >= this.MAX_NUMBER_OF_LINES)
			{
				
				this.util.removeFileLastLine(filePath);
			}
		
			String newLine = sms.getMsisdn()+";"+sms.getMessage()+";"+executionResult+";"+executionMessage;
			
			this.util.writeInLogFile(newLine, filePath);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		

}
