/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.orangecameroon.first_trust;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLContext;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;

/**
 *
 * @author ndziePatrickJoel - Software Factory - Orange Cameroon
 */
public class API {
    
	public  Registry<ConnectionSocketFactory> getRegistry() throws KeyManagementException, NoSuchAlgorithmException {
	    SSLContext sslContext = SSLContexts.custom().build();
	    SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContext,
	            new String[]{"TLSv1.2"}, null, SSLConnectionSocketFactory.getDefaultHostnameVerifier());
	    return RegistryBuilder.<ConnectionSocketFactory>create()
	            .register("http", PlainConnectionSocketFactory.getSocketFactory())
	            .register("https", sslConnectionSocketFactory)
	            .build();
	}
    
    /**
     * This function take
     * @param username
     * @param password
     * @param targetUrl
     * @return token or null
     * @throws ClientProtocolException
     * @throws IOException
     * @throws NoSuchAlgorithmException 
     * @throws KeyManagementException 
     */
    public String authenticate(String username, String password, String targetUrl) throws ClientProtocolException, IOException, KeyManagementException, NoSuchAlgorithmException
    {
    	PoolingHttpClientConnectionManager clientConnectionManager = new PoolingHttpClientConnectionManager(getRegistry());
        clientConnectionManager.setMaxTotal(100);
        clientConnectionManager.setDefaultMaxPerRoute(20);
        HttpClient client = HttpClients.custom().setConnectionManager(clientConnectionManager).build();
        
        System.out.println(username);
        System.out.println(password);
        
        HttpPost httpPost = new HttpPost(targetUrl);
        
        String json = "{\"username\":\""+username+"\",\"password\":\""+password+"\"}";
        StringEntity entity = new StringEntity(json);
        httpPost.setEntity(entity);
        httpPost.setHeader("Accept", "application/json");
        httpPost.setHeader("Content-type", "application/json");
     
        CloseableHttpResponse response = (CloseableHttpResponse) client.execute(httpPost);
        
        if(response.getStatusLine().getStatusCode() == 200)
        {
        	String content = EntityUtils.toString(response.getEntity());
        	
        	System.out.println(content);
        	
        	JsonParser parser = new JsonParser();
        	
        	JsonObject jsonObject = parser.parse(content).getAsJsonObject();
        	
        	java.lang.reflect.Type mapType = new TypeToken<Map<String, Object>>(){}.getType();
        	
        	Gson gson = new Gson();
        	Map<String, Object> mapResponse = gson.fromJson(jsonObject, mapType );
        	
        	return (String) mapResponse.get("token");
        }
        
        else
        {
        	String content = EntityUtils.toString(response.getEntity());
        	
        	System.out.println(content);
        	JsonParser parser = new JsonParser();
        	JsonObject jsonObject = parser.parse(content).getAsJsonObject();
        	java.lang.reflect.Type mapType = new TypeToken<Map<String, Object>>(){}.getType();
        	
        	Gson gson = new Gson();
        	Map<String, Object> mapResponse = gson.fromJson(jsonObject, mapType );
        	return null;
        }
    }
    
    /**
     * This function take
     * @param username
     * @param password
     * @param targetUrl
     * @return token or null
     * @throws ClientProtocolException
     * @throws IOException
     * @throws NoSuchAlgorithmException 
     * @throws KeyManagementException 
     */
    public int sendSMS(String message, String msisdn, String targetUrl, String token, 
    		String[] bundleExpiredKeys, String[] insufficientCreditKeys) throws ClientProtocolException, IOException, KeyManagementException, NoSuchAlgorithmException
    {

    	PoolingHttpClientConnectionManager clientConnectionManager = new PoolingHttpClientConnectionManager(getRegistry());
        clientConnectionManager.setMaxTotal(100);
        clientConnectionManager.setDefaultMaxPerRoute(20);
        HttpClient client = HttpClients.custom().setConnectionManager(clientConnectionManager).build();
        HttpPost httpPost = new HttpPost(targetUrl);
        
        String[] msisdnList = msisdn.split("\\,");
        
        String msisdnArray = "";
        
        for(int i = 0; i < msisdnList.length; i++)
        {
        	String validMsisdn = msisdnList[i];
        	
        	if(validMsisdn.length() > 9 && validMsisdn.substring(3).length() == 9)
        	{
        		validMsisdn = validMsisdn.substring(3);
        	}
        	
        	//msisdnArray += "\""+msisdnList[i]+"\",";
        	
        	msisdnArray += "\""+validMsisdn+"\",";
        }
        
        msisdnArray = msisdnArray.substring(0, msisdnArray.length() - 1);
        
        String json = "{\"messageContent\":\""+message+"\", \"projectName\": \"SCB\",  \"campaignTitle\": \"SCB\", \"recipients\":["+msisdnArray+"]}";
        
        StringEntity entity = new StringEntity(json);
        httpPost.setEntity(entity);
        httpPost.setHeader("Accept", "application/json");
        httpPost.setHeader("Content-type", "application/json");
        httpPost.setHeader("Authorization", "Bearer "+token);
     
        CloseableHttpResponse response = (CloseableHttpResponse) client.execute(httpPost);
        
        
        if(response.getStatusLine().getStatusCode() == 201 || response.getStatusLine().getStatusCode() == 200)
        {
        	System.out.println("Message successfully sent");
        	return 1;
        }
        
        else
        {
        	String content = EntityUtils.toString(response.getEntity()).trim();  
        	
        	System.out.println(content);
        	
        	if(this.stringContainsItemFromList(content, bundleExpiredKeys))
        	{
        		System.out.println("Bundle expired");
        		return 3;
        	}
        	
        	if(this.stringContainsItemFromList(content, insufficientCreditKeys))
        	{
        		System.out.println("Insufficient credit");
        		return 2;
        	}
        	
        	return 0;
        }
    }
    
    
    public boolean stringContainsItemFromList(String inputStr, String[] items)
    {
    	
    	
        for(int i =0; i < items.length; i++)
        {
            if(!inputStr.contains(items[i]))
            {
                return false;
            }
        }
        
        return true;
    }
    
   
}
