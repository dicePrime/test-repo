/**
 * 
 */
package com.orangecameroon.entity;

import javax.servlet.http.HttpServletRequest;

import static java.nio.charset.StandardCharsets.*;

/**
 * @author ndziePatrickJoel/joelpatrickndzie@gmail.com
 * 
 * This class represent a one shot SMS it contains all elements needed to send
 * one sms to the api
 *
 */
public class OneShotSMS {
	
	private String date;
	private String executionMessage;
	private String executionResult;
	private String msisdn;
	private String message;
	private String username;
	private String password;
	
	public OneShotSMS(HttpServletRequest request)
	{
		this.msisdn = request.getParameter("msisdn").toString();		
		this.message = request.getParameter("msg").toString();	
		
		byte ptext[] = this.message.getBytes(ISO_8859_1); 
		this.message = new String(ptext, UTF_8); 
		
	}
	
	public OneShotSMS(String logLine)
	{
		String[] data = logLine.trim().split("\\;");
		
		if(data.length >= 4)
		{
			this.date = data[0];
			this.msisdn = data[1];
			this.message = data[2];
			this.executionResult = data[3];
			if(data.length >= 5)
			{
				this.executionMessage = data[4];
			}
		}
	}
	
	public String toString()
	{
		StringBuilder stb = new StringBuilder();
		stb.append(this.msisdn);
		stb.append(System.getProperty("line.separator"));
		stb.append(this.username);
		stb.append(System.getProperty("line.separator"));
		stb.append(this.password);
		stb.append(System.getProperty("line.separator"));
		stb.append(this.message);
		return stb.toString();
		
	}
	
	/**
	 * 
	 * This method returns a boolean 
	 * @return boolean
	 */
	public boolean isCompliant()
	{
		if(null == this.msisdn || null == this.username || null == this.password || null == message)
		{
			return false;
		}
		
		return false;
		
	}
	
	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getExecutionMessage() {
		return executionMessage;
	}

	public void setExecutionMessage(String executionMessage) {
		this.executionMessage = executionMessage;
	}

	public String getExecutionResult() {
		return executionResult;
	}

	public void setExecutionResult(String executionResult) {
		this.executionResult = executionResult;
	}
}
