package com.orangecameroon.entity;

public class SMSResponse {

	
	public int executionResult;
	
	public String executionMessage;
	
	
	public SMSResponse(int executionResult, String executionMessage)
	{
		this.executionResult = executionResult;
		this.executionMessage = executionMessage;
	}
}
