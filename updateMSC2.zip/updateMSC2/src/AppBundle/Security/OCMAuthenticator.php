<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Security;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Guard\AbstractGuardAuthenticator;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Symfony\Component\Security\Core\User\UserProviderInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Description of OCMAuthenticator
 *
 * @author BMHB8456
 */
class OCMAuthenticator extends AbstractGuardAuthenticator {
    //put your code here
    
    
    private $container;
    
    
    public function __construct(ContainerInterface $container) {
        
        $this->container = $container;
    }
    
    /**
     * Called on every request. Return whatever credentials you want to
     * be passed to getUser(). Returning null will cause this authenticator
     * to be skipped.
     */
    public function getCredentials(Request $request)
    {
        
        if ($request->getPathInfo() != '/login') 
         {
             return;
         }

         $username = $request->get('_username');
         $password = $request->get('_password');


         if($password === null || $username === null)
         {
             return;
         }

         return array(
             'username' => $username,
             'password' => $password
         );
        
    }

    public function checkCredentials($credentials, UserInterface $user) 
    {        
        $cuid = $credentials["username"];

        $password = $credentials["password"];

        $key = urlencode('af3baf6222092e4b6ee0a04c1a076b19');
        
        /*$url="http://172.21.55.39/uaconsole/index.php/UserAccessConsole/authentify?cuid=$cuid&password=$password&key=$key";
        
        $native_response= file_get_contents($url);
        $json_response=  json_decode($native_response,true);
        
        $valeur_authentication=$json_response['AUTH'];*/
        
        //return $valeur_authentication;    
        
        return true;
    }

    public function getUser($credentials, UserProviderInterface $userProvider) {
        
        $username = $credentials['username'];
        
        if(null === $username)
        {
            return;
        }
        
        return $userProvider->loadUserByUsername($username);
    }

    public function onAuthenticationFailure(Request $request, AuthenticationException $exception) {
       // die($this->container->get('router')->generate('homepage'));
            
        die($exception->getMessage());
        die("authentication failed test");
            
            
            $data = array(
                'error' => strtr($exception->getMessageKey(), $exception->getMessageData())
            );
            $request->request->set('error', strtr($exception->getMessageKey(), $exception->getMessageData()));
            return new RedirectResponse($this->container->get('router')->generate('login'));
    }

    public function onAuthenticationSuccess(Request $request, TokenInterface $token, $providerKey) 
    {        
       // die($this->container->get('router')->generate('homepage'));   
        //die("user fully authenticated test");
        
        
                
       /*$user =   $this->container->get('security.token_storage')->getToken()->getUser();
        
        die($user->getUsername());
        
        $token = new UsernamePasswordToken($token, null, 'default', $user->getRoles());*/
        
        $this->container->get("security.token_storage")->setToken($token);
        
        /*die($token);*/
                
        return new RedirectResponse($this->container->get('router')->generate('homepage'));
    }

    public function start(Request $request, AuthenticationException $authException = null) {
        $data = array(
            // you might translate this message
            'message' => 'Vous devez vous identifier',
            'error' => null
        );
        
        $request->request->set('error', null);

        return new RedirectResponse($this->container->get('router')->generate('login'));
    }

    public function supportsRememberMe() {
        
        return false;
    }
    
    protected function getDefaultSuccessRedirectUrl()
    {
        return $this->container->get('router')->generate('homepage');
    }
    
    protected function getLoginUrl()
    {
       return $this->container->get('router')
                    ->generate('login');
    }

}
