<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Security;

use AppBundle\Entity\User;
use Symfony\Component\Security\Core\User\UserProviderInterface;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\Exception\UsernameNotFoundException;
use Symfony\Component\Security\Core\Exception\UnsupportedUserException;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Description of UtilisateurProvider
 *
 * @author ndziePatrick
 */
class UserProvider implements UserProviderInterface {
    //put your code here
    
    private $uaconsoleHost;
    private $uaconsoleKey;
    private $container;
    
    public function __construct($uaconsole_host, $uaconsole_key, ContainerInterface $container) {
        
        $this->uaconsoleHost = $uaconsole_host;
        $this->uaconsoleKey = $uaconsole_key;
        $this->container = $container;
    }
    
    public function getUserInfos($login)
    {
      $cuid = urlencode($login);
      $key = urlencode($this->uaconsoleKey);
      $url = $this->uaconsoleHost."/getuserinfo?cuid=$cuid&key=$key";
      
      $rawResponse = file_get_contents($url);
      
      $jsonResponse = json_decode($rawResponse, true);
      
      return $jsonResponse;
    }
    
    public function authentify($login, $pass)
    {
        /*$cuid = urlencode($login);

        $password = urlencode($pass);

        $key = urlencode('af3baf6222092e4b6ee0a04c1a076b19');
        
        $url="http://172.21.55.39/uaconsole/index.php/UserAccessConsole/authentify?cuid=$cuid&password=$password&key=$key";
        
        $native_response= file_get_contents($url);
        $json_response=  json_decode($native_response,true);
        
        $valeur_authentication=$json_response['AUTH'];*/
        
        //return $valeur_authentication;
        return true;
    }
    
    public function fetchNewUser(User $user)
    {
        
        
        $userData = $this->getUserInfos($user->getUsername());
        
        $fichier = fopen("testData.txt", "w+");
        fputs($fichier, print_r($userData, true));
        fclose($fichier);
      
        
        if($userData)
        {
            $user->setMatricule(array_key_exists('MATRICULE', $userData) ? $userData['MATRICULE'] : $user->getMatricule());
            $user->setNom(array_key_exists('NOM', $userData) ? $userData['NOM'] : $user->getNom());
            $user->setEmail(array_key_exists('EMAIL', $userData) ? $userData['EMAIL'] : $user->getEmail());
            $user->setDirection(array_key_exists('DIRECTION', $userData) ? $userData['DIRECTION'] : $user->getDirection());
            $user->setService(array_key_exists('SERVICE', $userData) ? $userData['SERVICE'] : $user->getService());
            $user->setDepartement(array_key_exists('DEPARTEMENT', $userData) ? $userData['DEPARTEMENT'] : $user->getDepartement());
            $user->setNature(array_key_exists('NATURE', $userData) ? $userData['NATURE'] : $user->getNature());
            $user->setProfilStaf(array_key_exists('PROFIL_STAF', $userData) ? $userData['PROFIL_STAF'] : $user->getProfilStaf());
        }
        
        return $user;
    }
    
    public function loadUserByUsername($username) {
        
        //on charge l'utilisateur à partir de la base de données
        //s'il existe déjà on ne regarde plus côté api.
        
        //lors de la  première connexion, si l'utilisateur n'existe pas dans la base de 
        //données on l'ajoute
        
        $em = $this->container->get('doctrine')->getManager();
        
        $user = $em->getRepository("AppBundle:User")->find($username);
        
        if($user)
        {
            $user->setRoles(array("ROLE_USER"));
            return $user;
        }
        
        else
        {        
            $userData = $this->getUserInfos($username);     
        }
                
        if($userData)
        {
            $utilisateur = new User($username, null, null);
            
            $utilisateur->setMatricule($userData['MATRICULE']);
            
            $utilisateur->setNomDirection($userData['DIRECTION']);
            
            $utilisateur->setNom($userData['NOM']);
            
            $utilisateur->setEmail($userData['EMAIL']);
                        
            // à ce niveau on charge les informations de l'utilisateurs contenues dans l'application          
                        
            return $utilisateur;
        }
        
        throw new UsernameNotFoundException(sprintf('Username "%s" does not exist.', $username));
    
    }
    
    
    public function refreshUser(UserInterface $user)
    {
        if(!$user instanceof User)
        {
            throw new UnsupportedUserException("Instances of '%s' are not supported", get_class($user));
        }
        
        return $this->loadUserByUsername($user->getUsername());
    }
    
    public function supportsClass($class) {
        
        return User::class === $class;
    }
    
    /**
     * 
     * Cette fonction permet de récupérer la hiérachie d'un utilisateur
     * elle récupère son chef de service, son chef de département et son directeur
     * @return type
     */
    public function getHierachie($login)
    {
      $cuid = urlencode($login);
      $key = urlencode($this->uaconsoleKey);
      $url = urlencode($this->uaconsoleHost."/getHierachie?cuid=$cuid&key=$key");
      
      $rawResponse = file_get_contents($url);
      
      return json_decode($rawResponse, true);        
    }
    
    
}
