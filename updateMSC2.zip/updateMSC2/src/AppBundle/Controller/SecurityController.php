<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;

/**
 * Description of SecurityController
 *
 * @author BMHB8456
 */
class SecurityController extends Controller {
    //put your code here

    /**
     * @Route("/login", name="login")
     */
    public function loginAction(Request $request) 
    {
        
        $user = $this->getUser();
        
        //print(get_class($user));
        
        if (get_class($user)== "AppBundle\Entity\User") 
        {
            //die("In controller");
          return $this->redirectToRoute('homepage');
        }
        
        $exception = $this->get('security.authentication_utils')
      ->getLastAuthenticationError();

    return $this->render('default/login.html.twig', [
      'error' => $exception ? $exception->getMessage() : NULL,
    ]);
    }
    
    

}
