<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

class DefaultController extends Controller
{
    /**
     * @Route("/", name="homepage")
     */
    public function indexAction(Request $request)
    {
        //die("really in homepage");
        // replace this example code with whatever you need
        $this->initTypesLivrables($request);
        $this->initTypesContrats($request);
        return $this->render('default/index.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.root_dir').'/..').DIRECTORY_SEPARATOR,
        ]);
    }
    
    
    public function loginAction(Request $request)
    {
                       
        $login = $request->get("login");
        $password = $request->get("password");
        
        if($login != null && $password != null)
        {
            if($this->get('app.user_provider')->authentify($login, $password) == true)
            {
                $utilisateur = $this->get('app.user_provider')->loadUserByUsername($login);
                
                //$utilisateur = $dao->find("AppBundle\Entity\User", 3);

                //$this->

                return $this->redirectToRoute("homepage");
            }

            else if($this->get('app.user_manager')->authentify($login, $password) == false)
            {
               $badCredentials = true; 
            } 
        }       
        
        else
        {
            $badCredentials = false;
        }
        
        return $this->render('default/login.html.twig', 
                array(
                    'badCredentials' => $badCredentials,
                    'base_dir' => realpath($this->container->getParameter('kernel.root_dir') . '/..')));
    }
    
    private function initTypesContrats(Request $request)
    {
        if($request->getSession()->get('typesContrats') == null)
        {
          $em = $this->get('doctrine')->getManager();        
          $typesContrats = $em->getRepository("AppBundle:TypeContrat")->findAll();
          $request->getSession()->set('typesContrats', $typesContrats);
        }
         
    }
    
    private function initTypesLivrables(Request $request)
    {
        /*'texte court' => 'texte court',
                'texte long' => 'texte long',
                'fichiers' => 'fichiers',
                'date' => 'date',
                'entier' => 'entier',
                'numerique*/
        
        if($request->getSession()->get('typesLivrables') == null)
        {
            $request->getSession()->set('typesLivrables', array(
                'texte long', 
                'texte court', 
                'date', 
                'fichiers', 
                'entier',
                'entier',
                'reel'
            ));
        }
    }
    /**
     * @Route("/not_found", name="not_found")
     */
    private function redirectTo404(Request $request) {
        return $this->render('default/notFound.html.twig');
    }
}
