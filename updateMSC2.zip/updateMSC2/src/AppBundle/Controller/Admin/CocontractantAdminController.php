<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Controller\Admin;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Form\CocontractantType;
use AppBundle\Entity\Cocontractant;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Description of TypeDocumentAdminController
 *
 * @author ndziePatrick
 */
class CocontractantAdminController extends Controller {
    //put your code here

    /**
     * @Route("/admin/concontractants/list", name="concontractants_list")
     */
    public function indexAction() {
        // replace this example code with whatever you need
        //on récupère l'entity manager
        $em = $this->get('doctrine')->getManager();

        $elements = $em->getRepository("AppBundle:Cocontractant")->findAll();

        $typesAdresses = $em->getRepository("AppBundle:TypeAdresse")->findAll();

        return $this->render('admin/cocontractants/cocontractantsList.html.twig', [
                    'elements' => $elements,
                    'typesAdresses' => $typesAdresses,
                    'base_dir' => realpath($this->getParameter('kernel.root_dir') . '/..') . DIRECTORY_SEPARATOR,
        ]);
    }

    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/admin/cocontractants/delete/{id}",
     *  name="delete_cocontractant",
     *  options = {"expose" = true })
     */
    public function deleteElementAction(Request $request, $id) {
        try {
            $em = $this->get('doctrine')->getManager();
            $role = $em->getRepository("AppBundle:Cocontractant")->find($id);

            if (!$role) {
                return new JsonResponse(json_encode(array("result" => 0,
                            "data" => "L'élement que vous essayez de supprimer n'existe plus")));
            } else {
                $em->remove($role);
                $em->flush();
                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => "")));
            }
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControllerAction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }

    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/admin/cocontractants/update/{id}",
     *  name="update_cocontractant",
     *  options = {"expose" = true })
     */
    public function updateElementAction(Request $request, $id) {
        try {
            $em = $this->get('doctrine')->getManager();
            $cocontractant = $em->getRepository("AppBundle:Cocontractant")->find($id);
            if (!$cocontractant) {

                return new JsonResponse(json_encode(array("result" => 0,
                            "data" => "L'élement que vous essayez de mettre à jour n'existe pas")));
            } else {
                $adresses = $cocontractant->getAdresses();

                foreach ($adresses as $adresse) {
                    $em->remove($adresse);
                }
                $em->flush();
                $result = $this->persistElement($request, $cocontractant);
                return new JsonResponse(json_encode($result));
            }
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControlleraction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }
    
    /**
     * @Route("/admin/cocontractants/create_return_new_element",
     *  name="create_return_new_cocontractant",
     *  options={"expose" = true})
     */
    public function createAndReturnElementAction(Request $request)
    {      
        $em = $this->get('doctrine')->getManager();
        $em->getConnection()->beginTransaction();
       try {
           $cocontractant = new Cocontractant();
           $form = $this->createForm(CocontractantType::class, $cocontractant);

          $data = json_decode($request->getContent(), true);
          $form->submit($data);
        if ($form->isValid()) 
        {
            $cocontractant = $form->getData();
            $em->persist($cocontractant);
            foreach ($cocontractant->getAdresses() as $adresse) 
            {
                $adresse->setCocontractant($cocontractant);
                $em->persist($adresse);
            }

            $em->flush();
            $status = "SUCCESS";
            $result = ["result" => 1, 
                       "data" => array("id"=> $cocontractant->getId(), 
                                       "nom" => $cocontractant->getNom())];
            $em->getConnection()->commit();
        }
        
        else
        {
            $status = "ERROR";
            $result = ["result" => 0, "data" => $this->get('app.tools')->getFormErrorMessages($form)]; 
            $em->getConnection()->rollBack();
        }
            return new JsonResponse(json_encode($result));
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControllerAction($request, $ex);
            $em->getConnection()->rollBack();
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        } 
    }

    /**
     * @Route("/admin/cocontractants/new_element",
     *  name="new_cocontractant",
     *  options={"expose" = true})
     */
    public function newElementAction(Request $request) {
        try {
            $result = $this->persistElement($request, null);
            return new JsonResponse(json_encode($result));
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControllerAction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }

    /**
     * @param Request $request
     * @param type $type
     * @return type
     */
    private function persistElement(Request $request, $type) {
        $cocontractant = $type == null ? new Cocontractant() : $type;
        $em = $this->get('doctrine')->getManager();
        $form = $this->createForm(CocontractantType::class, $cocontractant);

        $data = json_decode($request->getContent(), true);
        $form->submit($data);
        if ($form->isValid()) {
            $cocontractant = $form->getData();

            if ($type == null) {
                $em->persist($cocontractant);
            }

            foreach ($cocontractant->getAdresses() as $adresse) {
                $adresse->setCocontractant($cocontractant);
                $em->persist($adresse);
            }

            $em->flush();
            $status = "SUCCESS";
            $result = ["result" => 1];
        } else {
            $status = "ERROR";
            $result = ["result" => 0, "data" => $this->get('app.tools')->getFormErrorMessages($form)];
        }
        return $result;
    }

    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/admin/cocontractants/adresses/{id}",
     *  name="adresses_cocontractant",
     *  options = {"expose" = true })
     */
    public function getAdressesForCocontractantAction(Request $request, $id) {
        try {
            $em = $this->get('doctrine')->getManager();
            $cocontractant = $em->getRepository("AppBundle:Cocontractant")->find($id);

            if (!$cocontractant) {
                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => array())));
            } else {

                $adressesObjects = $cocontractant->getAdresses();

                $adresses = [];

                foreach ($adressesObjects as $adresse) {
                    $adresses[] = ['type' => $adresse->getType()->getId(),
                        'adresse' => $adresse->getAdresse()];
                }


                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => $adresses)));
            }
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControlleraction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }

}
