<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Controller\Admin;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Form\TypeAdresseType;
use AppBundle\Entity\TypeAdresse;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Description of TypeDocumentAdminController
 *
 * @author ndziePatrick
 */
class TypeAdresseAdminController extends Controller {
    //put your code here

    /**
     * @Route("/admin/types_adresses/list", name="types_adresses_list")
     */
    public function indexAction() {
        // replace this example code with whatever you need
        //on récupère l'entity manager
        $em = $this->get('doctrine')->getManager();

        $elements = $em->getRepository("AppBundle:TypeAdresse")->findAll();


        return $this->render('admin/typesAdresses/typesAdressesList.html.twig', [
                    'elements' => $elements,
                    'base_dir' => realpath($this->getParameter('kernel.root_dir') . '/..') . DIRECTORY_SEPARATOR,
        ]);
    }
    
    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/admin/types_adresses/delete/{id}",
     *  name="delete_type_adresse",
     *  options = {"expose" = true })
     */
    public function deleteElementAction(Request $request, $id)
    {
        try
        {
            $em = $this->get('doctrine')->getManager();
            $typeAdresse = $em->getRepository("AppBundle:TypeAdresse")->find($id);
            
            if(!$typeAdresse)
            {
                return new JsonResponse(json_encode(array("result" => 0,
                    "data" => "L'élement que vous essayez de supprimer n'existe plus")));
            }
            else
            {
                $em->remove($typeAdresse);
                $em->flush();
                return new JsonResponse(json_encode(array("result" => 1,
                    "data" => "")));
            }
        } catch (\Exception $ex) {
             $this->get('app.tools')->writeExceptionFromControllerAction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }

    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/admin/types_adresses/update/{id}",
     *  name="update_type_adresse",
     *  options = {"expose" = true })
     */
    public function updateElementAction(Request $request, $id) {
        try {
            $em = $this->get('doctrine')->getManager();
            $role = $em->getRepository("AppBundle:TypeAdresse")->find($id);

            if (!$role) {
                return new JsonResponse(json_encode(array("result" => 0,
                            "data" => "L'élement que vous essayez de mettre à jour n'existe pas")));
            } else {

                $result = $this->persistElement($request, $role);
                return new JsonResponse(json_encode($result));
            }
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControllerAction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }
    
    /**
     * @Route("/admin/types_adresses/new_element",
     *  name="new_type_adresse",
     *  options={"expose" = true})
     */
    public function newElementAction(Request $request) {
        try {
            $result = $this->persistElement($request, null);
            return new JsonResponse(json_encode($result));
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControllerAction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }

    private function persistElement(Request $request, $type) 
    {
        $typeAdresse = $type == null ? new TypeAdresse() : $type;
        $em = $this->get('doctrine')->getManager();
        $form = $this->createForm(TypeAdresseType::class, $typeAdresse);
        $form->submit($request->request->all());

        if ($form->isValid()) {
            $typeAdresse = $form->getData();
            if($type == null)
            {
               $em->persist($typeAdresse); 
            }            
            $em->flush();
            $status = "SUCCESS";
            $result = ["result" => 1];
        } else {
            $status = "ERROR";
            $result = ["result" => 0, "data" => $this->get('app.tools')->getFormErrorMessages($form)];
        }
        return $result;
    }

}
