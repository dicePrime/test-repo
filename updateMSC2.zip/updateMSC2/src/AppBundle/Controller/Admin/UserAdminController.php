<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Controller\Admin;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Form\UserType;
use AppBundle\Entity\User;
use Symfony\Component\HttpFoundation\JsonResponse;
use AppBundle\Form\UpdateUserType;

/**
 * Description of TypeDocumentAdminController
 *
 * @author ndziePatrick
 */
class UserAdminController extends Controller {
    //put your code here

    /**
     * @Route("/admin/users/list", name="users_list")
     */
    public function indexAction() {
        // replace this example code with whatever you need
        //on récupère l'entity manager
        $em = $this->get('doctrine')->getManager();

        $elements = $em->getRepository("AppBundle:User")->findAll();
        
        $roles = $em->getRepository("AppBundle:Role")->findAll();

        return $this->render('admin/users/usersList.html.twig', [
                    'elements' => $elements,
                    'roles' => $roles,
                    'base_dir' => realpath($this->getParameter('kernel.root_dir') . '/..') . DIRECTORY_SEPARATOR,
        ]);
    }
    
    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/admin/users/delete/{id}",
     *  name="delete_user",
     *  options = {"expose" = true })
     */
    public function deleteElementAction(Request $request, $id)
    {
        try
        {
            $em = $this->get('doctrine')->getManager();
            $user = $em->getRepository("AppBundle:User")->find($id);
            
            if(!$user)
            {
                return new JsonResponse(json_encode(array("result" => 0,
                    "data" => "L'élement que vous essayez de supprimer n'existe plus")));
            }
            else
            {
                $em->remove($user);
                $em->flush();
                return new JsonResponse(json_encode(array("result" => 1,
                    "data" => "")));
            }
        } catch (\Exception $ex) {
             $this->get('app.tools')->writeExceptionFromControllerAction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }

    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/admin/users/update/{id}",
     *  name="update_user",
     *  options = {"expose" = true })
     */
    public function updateElementAction(Request $request, $id) {
        try {
            $em = $this->get('doctrine')->getManager();
            $user = $em->getRepository("AppBundle:User")->find($id);

            if (!$user) 
            {
                return new JsonResponse(json_encode(array("result" => 0,
                            "data" => "L'élement que vous essayez de mettre à jour n'existe pas")));
            } else {

                $result = $this->persistElement($request, $user);
                return new JsonResponse(json_encode($result));
            }
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControlleraction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }
    
    /**
     * @Route("/admin/users/new_element",
     *  name="new_user",
     *  options={"expose" = true})
     */
    public function newElementAction(Request $request) {
        try {
            $result = $this->persistElement($request, null);
            return new JsonResponse(json_encode($result));
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControllerAction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }
    
     /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/admin/users/{id}/roles",
     *  name="roles_for_user",
     *  options = {"expose" = true })
     */
    public function getRolesForProfileAction(Request $request, $id)
    {
       try {
            $em = $this->get('doctrine')->getManager();
            $user = $em->getRepository("AppBundle:User")->find($id);

            if (!$user) {
                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => array())));
            } 
            else 
             {

                $rolesObjects = $user->getAppRoles();
                
                $roles = [];
                
                foreach($rolesObjects as $role)
                {
                    $roles[] = $role->getId();
                }
                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => $roles)));
            }
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControlleraction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        } 
    }

    private function persistElement(Request $request, $type) 
    {
        $user = $type == null ? new User(null, null, null) : $type;
        $em = $this->get('doctrine')->getManager();
        $form = $type == null ? $this->createForm(UserType::class, $user) : $this->createForm(UpdateUserType::class, $user);
        $form->submit($request->request->all());
         
        if ($form->isValid()) {
            $user = $form->getData();
            $user = $this->get('app.user_provider')->fetchNewUser($user);
            if($type == null)
            {               
               $em->persist($user); 
            }            
            $em->flush();
            $status = "SUCCESS";
            $result = ["result" => 1];
        } else {
            $status = "ERROR";
            $result = ["result" => 0, "data" => $this->get('app.tools')->getFormErrorMessages($form)];
        }
        return $result;
    }

}
