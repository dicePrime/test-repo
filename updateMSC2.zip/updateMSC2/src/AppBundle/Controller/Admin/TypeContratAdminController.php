<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Controller\Admin;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Form\TypeContratType;
use AppBundle\Entity\TypeContrat;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Description of TypeDocumentAdminController
 *
 * @author ndziePatrick
 */
class TypeContratAdminController extends Controller {
    //put your code here

    /**
     * @Route("/admin/types_contrats/list", name="types_contrats_list")
     */
    public function indexAction() {
        // replace this example code with whatever you need
        //on récupère l'entity manager
        $em = $this->get('doctrine')->getManager();

        $elements = $em->getRepository("AppBundle:TypeContrat")->findAll();
        
        $etats = $em->getRepository("AppBundle:Etat")->findAll();


        return $this->render('admin/typesContrats/typesContratsList.html.twig', [
                    'elements' => $elements,
                    'etats' => $etats,
                    'base_dir' => realpath($this->getParameter('kernel.root_dir') . '/..') . DIRECTORY_SEPARATOR,
        ]);
    }
    
    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/admin/types_contrats/delete/{id}",
     *  name="delete_type_contrat",
     *  options = {"expose" = true })
     */
    public function deleteElementAction(Request $request, $id)
    {
        try
        {
            $em = $this->get('doctrine')->getManager();
            $typeContrat = $em->getRepository("AppBundle:TypeContrat")->find($id);            
            if(!$typeContrat)
            {
                return new JsonResponse(json_encde(array("result" => 0,
                    "data" => "L'élement que vous essayez de supprimer n'existe plus")));
            }
            else
            {
                foreach($typeContrat->getNiveaux() as $niveau)
                {
                    $em->remove($niveau);
                }
                $em->remove($typeContrat);
                $em->flush();
                return new JsonResponse(json_encode(array("result" => 1,
                    "data" => "")));
            }
        } catch (\Exception $ex) {
             $this->get('app.tools')->writeExceptionFromControllerAction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }

    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/admin/types_contrats/update/{id}",
     *  name="update_type_contrat",
     *  options = {"expose" = true })
     */
    public function updateElementAction(Request $request, $id) {
        $em = $this->get('doctrine')->getManager();
        try {
            
            
            $em->getConnection()->beginTransaction();
            $typeContrat = $em->getRepository("AppBundle:TypeContrat")->find($id);

            if (!$typeContrat) {
                $em->rollBack();
                return new JsonResponse(json_encode(array("result" => 0,
                            "data" => "L'élement que vous essayez de mettre à jour n'existe pas")));
            } else {
                
                foreach($typeContrat->getNiveaux() as $niveau)
                {
                    $em->remove($niveau);
                }
                
                $em->flush();                
                $result = $this->persistElement($request, $typeContrat);
                $em->getConnection()->commit();
                return new JsonResponse(json_encode($result));
            }
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControllerAction($request, $ex);
            $em->getConnection()->rollBack();
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }
    
    /**
     * @Route("/admin/types_contrats/new_element",
     *  name="new_type_contrat",
     *  options={"expose" = true})
     */
    public function newElementAction(Request $request) {
        try {
            $this->get('doctrine')->getManager()->getConnection()->beginTransaction();
            $result = $this->persistElement($request, null);
            $this->get('doctrine')->getManager()->getConnection()->commit();
            return new JsonResponse(json_encode($result));
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControllerAction($request, $ex);
            $this->get('doctrine')->getManager()->getConnection()->rollBack();
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur > ". $ex->getMessage()))));
        }
    }

    private function persistElement(Request $request, $type) 
    {
        $typeContrat = $type == null ? new TypeContrat() : $type;
        $em = $this->get('doctrine')->getManager();
        $form = $this->createForm(TypeContratType::class, $typeContrat);
        
        $request->request->set("niveaux", json_decode($request->request->get("niveaux"), true));
        
        //if($request->files->get('template'))
        $form->submit($request->request->all());    
        
        $fichier = fopen("testFichiers.txt", "w+");
        fputs($fichier, print_r($request->request->all(), true));
        fclose($fichier);
         
        if ($form->isValid()) 
        {
            $typeContrat = $form->getData();
                                                    
            if($type == null)
            {
               $em->persist($typeContrat); 
            }  
            
            $file = $request->files->get('template'); 

            if($file != null)
            {
                $fileName = $file->getClientOriginalName(); 
                $typeContrat->setModele($fileName);
            }
            
            foreach ($typeContrat->getNiveaux() as $niveau) {
                $niveau->setTypeContrat($typeContrat);
                $em->persist($niveau);
            }
            
            $em->flush();
            
            if($file != null)
            {
                // enregistrement des fichiers
                $fileDir = "uploads/types_contrats/".$typeContrat->getId()."/modele";

                if(!is_dir($fileDir))
                {
                    mkdir($fileDir, 0777, true);
                }
                $file->move($fileDir, $fileName);    
            }
            
            $status = "SUCCESS";
            $result = ["result" => 1];
        } else {
            $status = "ERROR";
            $result = ["result" => 0, "data" => $this->get('app.tools')->getFormErrorMessages($form)];
        }

        return $result;
    }
    
    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/admin/types_contrats/niveaux/{id}",
     *  name="niveaux_type_contrat",
     *  options = {"expose" = true })
     */
    public function getNiveauxForTypeContratAction(Request $request, $id) {
        try {
            $em = $this->get('doctrine')->getManager();
            $typeContrat = $em->getRepository("AppBundle:TypeContrat")->find($id);

            if (!$typeContrat) {
                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => array())));
            } else {

                $niveauxObjects = $typeContrat->getNiveaux();

                $adresses = [];

                foreach ($niveauxObjects as $niveau) {
                    $adresses[] = ['niveau' => $niveau->getNiveau(),
                        'etat' => $niveau->getEtat()->getId()];
                }


                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => $adresses)));
            }
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControlleraction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }

}
