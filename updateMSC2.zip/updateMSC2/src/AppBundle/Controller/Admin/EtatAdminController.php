<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Controller\Admin;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Form\EtatType;
use AppBundle\Entity\Etat;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Description of EtatAdminController
 *
 * @author ndziePatrick
 */
class EtatAdminController extends Controller {
    //put your code here

    /**
     * @Route("/admin/etats/list", name="etats_list")
     */
    public function indexAction() {
        // replace this example code with whatever you need
        //on récupère l'entity manager
        $em = $this->get('doctrine')->getManager();

        $elements = $em->getRepository("AppBundle:Etat")->findAll();
        $roles = $em->getRepository("AppBundle:Role")->findAll();



        return $this->render('admin/etats/etatsList.html.twig', [
                    'elements' => $elements,
                    'roles' => $roles,
                    'base_dir' => realpath($this->getParameter('kernel.root_dir') . '/..') . DIRECTORY_SEPARATOR,
        ]);
    }

    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/admin/etats/delete/{id}",
     *  name="delete_etat",
     *  options = {"expose" = true })
     */
    public function deleteElementAction(Request $request, $id) {
        try {
            $em = $this->get('doctrine')->getManager();
            $etat = $em->getRepository("AppBundle:Etat")->find($id);

            if (!$etat) {
                return new JsonResponse(json_encode(array("result" => 0,
                            "data" => "L'élement que vous essayez de supprimer n'existe plus")));
            } else {
                $em->remove($etat);
                $em->flush();
                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => "")));
            }
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControllerAction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }

    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/admin/etats/update/{id}",
     *  name="update_etat",
     *  options = {"expose" = true })
     */
    public function updateElementAction(Request $request, $id) {
        try {
            $em = $this->get('doctrine')->getManager();
            $etat = $em->getRepository("AppBundle:Etat")->find($id);

            if (!$etat) {
                return new JsonResponse(json_encode(array("result" => 0,
                            "data" => "L'élement que vous essayez de mettre à jour n'existe pas")));
            } else 
            {
                
                $livrables = $etat->getLivrables();
                
                foreach($livrables as $livrable)
                {
                    $em->remove($livrable);
                }
                
                $em->flush();
                
                $result = $this->persistElement($request, $etat);
                return new JsonResponse(json_encode($result));
            }
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControllerAction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }

    /**
     * @Route("/admin/etats/new_element",
     *  name="new_etat",
     *  options={"expose" = true})
     */
    public function newElementAction(Request $request) {
        try {
            $result = $this->persistElement($request, null);
            return new JsonResponse(json_encode($result));
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControllerAction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }

    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/admin/etats/{id}/roles",
     *  name="roles_for_etat",
     *  options = {"expose" = true })
     */
    public function getRolesForEtatAction(Request $request, $id) {
        try {
            $em = $this->get('doctrine')->getManager();
            $etat = $em->getRepository("AppBundle:Etat")->find($id);

            if (!$etat) {
                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => array())));
            } else {

                $rolesObjects = $etat->getRoles();
                $roles = [];
                foreach ($rolesObjects as $role) {
                    $roles[] = $role->getId();
                }
                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => $roles)));
            }
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControlleraction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }

    private function persistElement(Request $request, $type) {
        $etat = $type == null ? new Etat() : $type;
        $em = $this->get('doctrine')->getManager();
        $form = $this->createForm(EtatType::class, $etat);
        //$form->submit($request->request->all());

        $data = json_decode($request->getContent(), true);

        $form->submit($data);

        if ($form->isValid()) {
            $etat = $form->getData();
            if ($type == null) {
                $em->persist($etat);
            }

            foreach ($etat->getLivrables() as $livrable) {
                $livrable->setEtat($etat);
                $em->persist($livrable);
            }
            $em->flush();
            $status = "SUCCESS";
            $result = ["result" => 1];
        } else {
            $status = "ERROR";
            $result = ["result" => 0, "data" => $this->get('app.tools')->getFormErrorMessages($form)];
        }
        return $result;
    }

    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/admin/etats/livrables/{id}",
     *  name="livrables_etat_etat",
     *  options = {"expose" = true })
     */
    public function getLivrablesForEtatAction(Request $request, $id) {
        try {
            $em = $this->get('doctrine')->getManager();
            $etat = $em->getRepository("AppBundle:Etat")->find($id);

            if (!$etat) {
                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => array())));
            } else {

                $livrablesObjects = $etat->getLivrables();

                $livrables = [];

                foreach ($livrablesObjects as $livrable) {
                    $livrables[] = ['type' => $livrable->getType(),
                        'requis' => $livrable->getRequis(),
                        'nom' => $livrable->getNom(),
                        'multiple' => $livrable->getMultiple()
                    ];
                }


                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => $livrables)));
            }
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControlleraction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }

}
