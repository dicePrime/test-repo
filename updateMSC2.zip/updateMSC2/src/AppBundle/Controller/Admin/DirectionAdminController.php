<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Controller\Admin;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Form\DirectionType;
use AppBundle\Form\NewDirectionType;
use AppBundle\Entity\Direction;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Description of TypeDocumentAdminController
 *
 * @author ndziePatrick
 */
class DirectionAdminController extends Controller {
    //put your code here

    /**
     * @Route("/admin/directions/list", name="directions_list")
     */
    public function indexAction() {
        // replace this example code with whatever you need
        //on récupère l'entity manager
        $em = $this->get('doctrine')->getManager();

        $elements = $em->getRepository("AppBundle:Direction")->findAll();


        return $this->render('admin/directions/directionsList.html.twig', [
                    'elements' => $elements,
                    'base_dir' => realpath($this->getParameter('kernel.root_dir') . '/..') . DIRECTORY_SEPARATOR,
        ]);
    }
    
    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/admin/directions/delete/{id}",
     *  name="delete_direction",
     *  options = {"expose" = true })
     */
    public function deleteElementAction(Request $request, $id)
    {
        try
        {
            $em = $this->get('doctrine')->getManager();
            $direction = $em->getRepository("AppBundle:Direction")->find($id);
            
            if(!$direction)
            {
                return new JsonResponse(json_encode(array("result" => 0,
                    "data" => "L'élement que vous essayez de supprimer n'existe plus")));
            }
            else
            {
                $em->remove($direction);
                $em->flush();
                return new JsonResponse(json_encode(array("result" => 1,
                    "data" => "")));
            }
        } catch (\Exception $ex) {
             $this->get('app.tools')->writeExceptionFromControllerAction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }

    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/admin/directions/update/{id}",
     *  name="update_direction",
     *  options = {"expose" = true })
     */
    public function updateElementAction(Request $request, $id) {
        try {
            $em = $this->get('doctrine')->getManager();
            $role = $em->getRepository("AppBundle:Direction")->find($id);

            if (!$role) {
                return new JsonResponse(json_encode(array("result" => 0,
                            "data" => "L'élement que vous essayez de mettre à jour n'existe pas")));
            } else {

                $result = $this->persistElement($request, $role);
                return new JsonResponse(json_encode($result));
            }
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControllerAction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }
    
    /**
     * @Route("/admin/directions/new_element",
     *  name="new_direction",
     *  options={"expose" = true})
     */
    public function newElementAction(Request $request) {
        try {
            $result = $this->persistElement($request, null);
            return new JsonResponse(json_encode($result));
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControllerAction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }

    private function persistElement(Request $request, $type) 
    {
        $direction = $type == null ? new Direction() : $type;
        $em = $this->get('doctrine')->getManager();
        $form = $type == null ? $this->createForm(NewDirectionType::class, $direction) : $this->createForm(DirectionType::class, $direction);
        $form->submit($request->request->all());

        if ($form->isValid()) {
            $direction = $form->getData();
            if($type == null)
            {
               $em->persist($direction); 
            }            
            $em->flush();
            $status = "SUCCESS";
            $result = ["result" => 1];
        } else {
            $status = "ERROR";
            $result = ["result" => 0, "data" => $this->get('app.tools')->getFormErrorMessages($form)];
        }
        return $result;
    }

}
