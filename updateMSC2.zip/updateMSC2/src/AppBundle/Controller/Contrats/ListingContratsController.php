<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Controller\Contrats;


use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\Contrat;
use AppBundle\Form\ContratType;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Description of ListingContratsController
 *
 * @author BMHB8456
 */
class ListingContratsController extends Controller {
    //put your code here
    
    /**
     * 
     */
    public function getElementsByStatusAction()
    {
        
    }
    
    /**
     * @Route("/mes_contrats", name="contrats_utilisateur", options = {"expose" = true })
     */
    public function contratsUtilisateurAction()
    {
        $user = $this->getUser();
        
        
        $em = $this->get('doctrine')->getManager();
        
        $elements = $em->getRepository("AppBundle:Contrat")->findBy(
        array('username' => $user->getUsername())        
        );
        
        return $this->render('contrats/userContrats.html.twig', [
                    'elements' => $elements,
                    'base_dir' => realpath($this->getParameter('kernel.root_dir') . '/..') . DIRECTORY_SEPARATOR,
        ]);
  
    }
}
