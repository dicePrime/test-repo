<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Controller\Contrats;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\Contrat;
use AppBundle\Form\ContratType;
use Symfony\Component\HttpFoundation\JsonResponse;


/**
 * Description of DetailsContratController
 *
 * @author BMHB8456
 */
class UpdateContratController extends Controller {
    //put your code here
    
    
    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/contrats/update_infos_contrat/{id}",
     *  name="update_infos_contrat",
     *  options = {"expose" = true })
     */
    public function updateInfosContratAction(Request $request, $id)
    {
        $em = $this->get('doctrine')->getManager();
        try
        {
            $contrat = $em->getRepository("AppBundle:Contrat")->find($id);
            
            if(!$contrat)
            {
                return new JsonResponse(json_encode(array("result" => 1, "data" => array())));
            }
        } catch (\Exception $ex) {

        }
    }
    
    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/get_documents_contrat/{id}",
     *  name="get_documents_contrat",
     *  options = {"expose" = true })
     */
    public function getDocumentsContratAction(Request $request, $id)
    {
       try {
            $em = $this->get('doctrine')->getManager();
            $contrat = $em->getRepository("AppBundle:Contrat")->find($id);

            if (!$contrat) {
                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => array())));
            } else {

                $documentsObjets = $contrat->getDocuments();

                $documents = [];

                foreach ($documentsObjets as $document) 
                {
                    $documents[] = ['type' => $document->getType()->getNom(),
                                    'nom' => $document->getNom(),
                                    'id' => $document->getId(),
                                    'chemin' => $document->getChemin()];
                }


                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => $documents)));
            }
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControlleraction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        } 
    }
    
     
    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/get_modalites_financieres_contrat/{id}",
     *  name="get_modalites_financieres_contrat",
     *  options = {"expose" = true })
     */
    public function getModalitesFinancieresContratAction(Request $request, $id)
    {
      try {
            $em = $this->get('doctrine')->getManager();
            $contrat = $em->getRepository("AppBundle:Contrat")->find($id);

            if (!$contrat) {
                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => array())));
            } 
            else 
            {

                $modalitesObjets = $contrat->getModalitesFinancieres();

                $modalites = [];

                foreach ($modalitesObjets as $modalite) 
                {
                    $modalites[] = [
                                    'nom' => $modalite->getNom(),
                                    'description' => $modalite->getId(),
                                    'montant' => $modalite->getMontant()];
                }


                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => $modalites)));
            }
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControlleraction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }   
    }
    
     /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/get_identification_contrat/{id}",
     *  name="get_identification_contrat",
     *  options = {"expose" = true })
     */
    public function getIdentificationContratAction(Request $request, $id)
    {
      try {
            $em = $this->get('doctrine')->getManager();
            $contrat = $em->getRepository("AppBundle:Contrat")->find($id);

            if (!$contrat) {
                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => array())));
            } 
            else 
            {
                $modalites = [
                    'codeChrono' => $contrat->getCodeChrono(),
                    'dateOuverture' => date_format($contrat->getDateOuverture(),"d/m/Y H:i:s"),
                    'entiteInitiatrice' => $contrat->getEntiteInitiatrice(),
                    'direction' => $contrat->getDirection()->getCode(),
                    'nomInitiateur' => $contrat->getNomInitiateur(),
                    'document' => $contrat->getDocument(),
                    'statut' => ""
                ];
              return new JsonResponse(json_encode(array("result" => 1,
                            "data" => $modalites)));
            }
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControlleraction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }   
    }
    
    
     /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/get_cocontractants_contrat/{id}",
     *  name="get_cocontractants_contrat",
     *  options = {"expose" = true })
     */
    public function getCocontractantsContratAction(Request $request, $id)
    {
      try {
            $em = $this->get('doctrine')->getManager();
            $contrat = $em->getRepository("AppBundle:Contrat")->find($id);

            if (!$contrat) {
                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => array())));
            } 
            else 
            {
                $cocontractants = [];
                
                foreach($contrat->getCocontractants() as $next)
                {
                    $cocontractants[] = ['nom' => $next->getNom(),
                                         'id' => $next->getId()];
                }
                
              return new JsonResponse(json_encode(array("result" => 1,
                            "data" => $cocontractants)));
            }
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControlleraction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }   
    }
    
    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/get_historiques_actions_contrat/{id}",
     *  name="get_historiques_actions_contrat",
     *  options = {"expose" = true })
     */
    public function getHistoriqueActionContrat(Request $request, $id)
    {
       try {
            $em = $this->get('doctrine')->getManager();
            $contrat = $em->getRepository("AppBundle:Contrat")->find($id);

            if (!$contrat) {
                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => array())));
            } 
            else 
            {

                $modalitesObjets = $contrat->getHistoriquesActions();

                $modalites = [];

                foreach ($modalitesObjets as $modalite) 
                {
                    
                    
                    $modalites[] = [
                                    'nom' => $modalite->getNom(),
                                    'nomUser' => $modalite->getNomUser(),
                                    'dateAction' => date_format($modalite->getDateAction(),"d/m/Y H:i:s"),
                                    'description' => $modalite->getId()
                                    ];
                }


                return new JsonResponse(json_encode(array("result" => 1,
                            "data" => $modalites)));
            }
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControlleraction($request, $ex);
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }    
    }
}
