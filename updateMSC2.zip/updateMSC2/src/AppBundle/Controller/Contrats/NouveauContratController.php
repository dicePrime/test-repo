<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Controller\Contrats;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\Contrat;
use AppBundle\Entity\Document;
use AppBundle\Form\ContratType;
use Symfony\Component\HttpFoundation\JsonResponse;
use AppBundle\Entity\NiveauValidation;
use AppBundle\Entity\LivrableNiveauValidation;

/**
 * Description of NouveauContratController
 *
 * @author ndziePatrick
 */
class NouveauContratController extends Controller {

    //put your code here
    /**
     * @Route("/contrats/nouveau", name="nouveau_contrat")
     */
    public function nouveauContratAction(Request $request) 
    {
        $em = $this->get('doctrine')->getManager();
        $cocontractants = $em->getRepository("AppBundle:Cocontractant")->findAll();
        $typesAdresses = $em->getRepository("AppBundle:TypeAdresse")->findAll();
        $directions = $em->getRepository("AppBundle:Direction")->findAll();
        $typesDocuments = $em->getRepository("AppBundle:TypeDocument")->findAll();

        return $this->render('contrats/nouveauContrat.html.twig', [
                    'cocontractants' => $cocontractants,
                    'typesAdresses' => $typesAdresses,
                    'directions' => $directions,
                    'typesDocuments' => $typesDocuments,
                    'base_dir' => realpath($this->getParameter('kernel.root_dir') . '/..') . DIRECTORY_SEPARATOR,
        ]);
    }

    /**
     * 
     * @param Request $request
     * @param type $id
     * 
     * @Route("/contrat/update/{id}",
     *  name="update_contrat",
     *  options = {"expose" = true })
     */
    public function updateElementAction(Request $request, $id) {
        $this->get('doctrine')->getManager()->getConnection()->beginTransaction();
        try {
            $em = $this->get('doctrine')->getManager();
            $contrat = $em->getRepository("AppBundle:Contrat")->find($id);

            if (!$contrat) {
                return new JsonResponse(json_encode(array("result" => 0,
                            "data" => "L'élement que vous essayez de mettre à jour n'existe pas")));
            } else {
                $documentsToDelete = json_decode($request->get("documentsToDelete"));
                
                $fichier = fopen("testDocumentToDelete.txt", "w+");
                fputs($fichier, print_r($documentsToDelete, true));
                fclose($fichier);

                // on supprime tous les documents à supprimer
                foreach ($contrat->getDocuments() as $nextDocument) 
                {
                    foreach ($documentsToDelete as $next)
                    {
                        if ($next == $nextDocument->getId()) {
                            $em->remove($nextDocument);
                            break;
                        }
                    }
                }
                
                $em->flush();
                
                $previousDocumentsContrat = $contrat->getDocuments();
                
                $toAddDocuments = [];
                
                foreach($previousDocumentsContrat as $document)
                 {
                     $toAddDocuments[] = [
                         'nom' => $document->getNom(),
                         'chemin' => $document->getChemin(),
                         'id' => $document->getId(),
                         'contrat' => $contrat,
                         'type' => $document->getType()
                     ];

                 }
                 
                 foreach($contrat->getDocuments() as $doc)
                 {
                     $em->remove($doc);
                 }
                 
                 $em->flush();
                
                // on supprime toutes les modalités financières existantes
                foreach ($contrat->getModalitesFinancieres() as $modalite) {
                    $em->remove($modalite);
                }

                // on supprime la relation du contrat avec les précédents cocontractants

                foreach ($contrat->getCocontractants() as $cocontractant) {
                    $cocontractant->removeContrat($contrat);
                }

                $em->flush();

                $request->request->remove("documentsToDelete");
                
                $result = $this->persistElement($request, $contrat);                
                $this->restoreOldDocuments($toAddDocuments, $em);
                
                $this->get('doctrine')->getManager()->getConnection()->commit();
                return new JsonResponse(json_encode($result));
            }
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControllerAction($request, $ex);
            $this->get('doctrine')->getManager()->getConnection()->rollBack();
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur"))));
        }
    }
    
    private function restoreOldDocuments($oldDocuments, $em)
    {
        foreach($oldDocuments as $next)
        {
            $tmpDoc = new Document();
            $tmpDoc->setChemin($next['chemin']);
            $tmpDoc->setContrat($next['contrat']);
            $tmpDoc->setType($next['type']);
            $tmpDoc->setNom($next['nom']);
            
            $em->persist($tmpDoc);
            
            $previousLocation = "uploads/documents/" . $next["id"]."/".$next['nom'];
            $newLocation = "uploads/documents/".$tmpDoc->getId()."/".$next['nom'];
            if (!is_dir($newLocation)) {
                 mkdir($newLocation, 0777, true);
                }
            move_uploaded_file($previousLocation, $newLocation);
                                
        }
        
        $em->flush();
    }

    /**
     * @Route("/contrats/persist",
     *  name="add_contrat",
     *  options={"expose" = true})
     */
    public function newElementAction(Request $request) {
        $this->get('doctrine')->getManager()->getConnection()->beginTransaction();
        try {

            $result = $this->persistElement($request, null);
            $this->get('doctrine')->getManager()->getConnection()->commit();
            return new JsonResponse(json_encode($result));
        } catch (\Exception $ex) {
            $this->get('app.tools')->writeExceptionFromControllerAction($request, $ex);
            $this->get('doctrine')->getManager()->getConnection()->rollBack();
            return new JsonResponse(json_encode(array("result" => 0, "data" => array("Erreur côté serveur, contactez l'administrateur > " . $ex->getMessage()))));
        }
    }

    private function modifyRequest(Request $request) {
        $request->request->set("modalitesFinancieres", json_decode($request->request->get("modalitesFinancieres"), true));
        $request->request->set("cocontractants", json_decode($request->get("cocontractants"), true));
        $request->request->set("documents", json_decode($request->get("documents"), true));
        
        if(count($request->request->get("documents")) < 1)
        {
          $request->request->set("documents", array());  
        }

        return $request;
    }

    private function createContrat(Contrat $contrat) {
        $dateCreation = new \Datetime();

        $contrat->setDateOuverture($dateCreation);

        $codeAlPhanum = uniqid() . "/" . date("my", time()) . "/" . $contrat->getDirection()->getCode();

        $contrat->setCodeChrono($codeAlPhanum);

        $contrat->setNomInitiateur($this->getUser()->getNom());

        return $contrat;
    }

    private function updateDocumentContrat(Request $request, Contrat $contrat) {
        $file = $request->files->get('contrat');

        if ($file != null) {
            $fileName = $file->getClientOriginalName();
            $contrat->setDocument($fileName);
        }

        return $contrat;
    }
    
    

    private function saveDocuments(Contrat $contrat, $documents, $em) 
    {

        if(count($documents) > 0)
        {
                $nullIds = [];
            $i = 0;
            foreach ($contrat->getDocuments() as $document) 
            {
                //c'est à ce niveau qu'on doit gérer les fichiers
                    if($document->getChemin() == null)
                    {
                        $tmpFile = $documents[$i];
                        $tmpFileName = $tmpFile->getClientOriginalName();   
                        $document->setChemin($tmpFileName);            
                        $document->setContrat($contrat);
                        $em->persist($document);
                        $i++;
                    }

            }
        }
        
    }

    private function saveModalitesFinancieres(Contrat $contrat, $em) {
        foreach ($contrat->getModalitesFinancieres() as $modalite) {
            $modalite->setContrat($contrat);
            $em->persist($modalite);
        }
    }

    private function saveCocontractants(Contrat $contrat) {
        foreach ($contrat->getCocontractants() as $cocontractant) {
            $cocontractant->addContrat($contrat);
        }
    }
   

    private function moveFiles(Request $request, Contrat $contrat, $documents) {
        $file = $request->files->get('contrat');
        if ($file != null) {
            $fileName = $file->getClientOriginalName();
            // enregistrement des fichiers
            $fileDir = "uploads/contrats/" . $contrat->getId() . "/contrat";

            if (!is_dir($fileDir)) {
                mkdir($fileDir, 0777, true);
            }
            $file->move($fileDir, $fileName);
        }

        $j = 0;
        foreach ($contrat->getDocuments() as $document)
        {
            if($document->getId() != null)
            {
                $tmpFileDir = "uploads/documents/" . $document->getId();
                $tmpFile = $documents[$j];
                $tmpFileName = $tmpFile->getClientOriginalName();

                if (!is_dir($tmpFileDir)) {
                    mkdir($tmpFileDir, 0777, true);
                }

                $documents[$j]->move($tmpFileDir, $tmpFileName);
                $j++;
            }
        }
    }

    private function saveHistoriqueAction(Contrat $contrat, $em, $type) 
    {
        $historiqueAction = new \AppBundle\Entity\HistoriqueActionContrat();
        $historiqueAction->setContrat($contrat);
        $historiqueAction->setDateAction(new \DateTime());
        $historiqueAction->setUsername($this->getUser()->getUsername());
        $historiqueAction->setNom(null == $type ? "CREATION" : "MISE A JOUR");
        $historiqueAction->setNomUser($this->getUser()->getNom());
        $em->persist($historiqueAction);
    }

    private function createNiveauxValidationAndLivrables(Contrat $contrat, $em) {
        $niveauxWorkflowBase = $contrat->getTypeContrat()->getNiveaux();

        foreach ($niveauxWorkflowBase as $nextNiveauBase) {
            $niveauValidation = new NiveauValidation();
            $niveauValidation->setContrat($contrat);
            $niveauValidation->setEtat($nextNiveauBase->getEtat());
            $niveauValidation->setNiveau($nextNiveauBase->getNiveau());

            $em->persist($niveauValidation);

            $livrablesEtat = $nextNiveauBase->getEtat()->getLivrables();

            foreach ($livrablesEtat as $nextLivrable) {
                $tmpLivrable = new LivrableNiveauValidation();

                $tmpLivrable->setNiveauValidation($niveauValidation);
                $tmpLivrable->setType($nextLivrable->getType());
                $tmpLivrable->setNom($nextLivrable->getNom());
                $tmpLivrable->setRequis($nextLivrable->getRequis());
                $em->persist($tmpLivrable);
            }
        }
    }

    private function persistElement(Request $request, $type) {
        $contrat = $type == null ? new Contrat() : $type;
        $em = $this->get('doctrine')->getManager();
        $form = $this->createForm(ContratType::class, $contrat);

        $request = $this->modifyRequest($request);

        $form->submit($request->request->all());


        if ($form->isValid()) {
            $contrat = $form->getData();
            if ($type == null) 
            {
                $contrat = $this->createContrat($contrat);
                $contrat->setUsername($this->getUser()->getUsername());
                $em->persist($contrat);  
                // on crée les niveaux de validation et leurs livrables associés
                $this->createNiveauxValidationAndLivrables($contrat, $em);
            }

            $contrat = $this->updateDocumentContrat($request, $contrat);

            $documents = $request->files->get('document');
                           
            $this->saveDocuments($contrat, $documents, $em);
            
            
            
             
            $this->saveModalitesFinancieres($contrat, $em);
            $this->saveCocontractants($contrat);
            $this->saveHistoriqueAction($contrat, $em, $type);
            $em->flush();
            $this->moveFiles($request, $contrat, $documents);
           
            $status = "SUCCESS";
            $result = ["result" => 1];
        } else {
            $status = "ERROR";
            $result = ["result" => 0, "data" => $this->get('app.tools')->getFormErrorMessages($form)];
        }

        return $result;
    }

}
