<?php

//src/AppBundle/Entity/Contrat.php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\Validator\Constraints as Assert;
/**
 * Description of Contract
 *
 * @author ndziePatrick
 * 
 * @ORM\Entity
 * @ORM\Table(name="contrat")
 */
class Contrat {
    //put your code here
    
    
    /**
     *
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;
    
    
    /**
     *
     * @ORM\Column(type="string", length=255)
     * @var string
     */
    private $entiteInitiatrice;
    
    
    /**
    *
    * @ORM\Column(type="integer")
    */
    private $dureeContrat;

    /**
    *
    * @ORM\Column(type="integer")
    */
    private $preavis;
    
    
    /**
     *
     * @ORM\Column(type="string", length=255)
     */
    private $codeChrono;

     /**
     *
     * @ORM\Column(type="string", length=5)
     */
    private $taciteReconduction;
    
    /**
     *
     * @ORM\ManyToOne(targetEntity="TypeContrat", inversedBy="contrats")
     * @ORM\JoinColumn(name="type_contrat", referencedColumnName="id")
     */
    private $typeContrat;
    
    /**
     * @ORM\ManyToOne(targetEntity="Direction", inversedBy="contrats")
     * @ORM\JoinColumn(name="code_direction", referencedColumnName="code")
     */
    private $direction;
                        
    /**
     *
     * @ORM\Column(type="datetime")
     */
    private $dateOuverture;
    
     /**
     * Plusieurs contrats ont plusieurs cocontractants.
     * @ORM\ManyToMany(targetEntity="Cocontractant", inversedBy="contrats")
     * @ORM\JoinTable(name="cocontractants_contrats")
     */
    private $cocontractants;
    
    /**
     * Un contrat peut avoir plusieurs cocontractants
     * @ORM\OneToMany(targetEntity="Document", mappedBy="contrat", cascade={"persist", "remove"})
     */
    private $documents;
    
    
    /**
     *
     * Un contrat peut avoir plusieurs modalités financières
     * @ORM\OneToMany(targetEntity="ModaliteFinanciere", mappedBy="contrat")
     */
    private $modalitesFinancieres;
    
    
    /**
     *
     * Un contrat peut avoir plusieurs modalités financières
     * @ORM\OneToMany(targetEntity="HistoriqueActionContrat", mappedBy="contrat")
     */
    private $historiquesActions;
    
    
     /**
     *
     * @ORM\Column(type="string", length=255)
     * 
     */
    private $document;
    
    /**
     *
     * @ORM\Column(type="text")
     */
    private $objet;
    
    
    /**
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $dateSignature;
    
    
    /**
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $datePriseEffet;
    
    
    /**
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $dateEcheance;
    
    /**
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $dateResiliation;
    
    /**
     *
     * @ORM\Column(type="integer")
     */
    private $etat = 0;
    
    
    
    /**
     * 
     * @Assert\File()
     */
    private $fichier;
    
    
    /**
     * l'identifiant unique de celui qui a crée le contrat
     * @ORM\Column(type="string", length= 64)
     */
    private $username;
    
    /**
     *
     * @ORM\Column(type="string", length=255)
     */
    private $nomInitiateur;
    
    /**
     * Un type de contrat peut avoir plusieurs instances
     * @ORM\OneToMany(targetEntity="NiveauValidation", mappedBy="contrat")
     */
    private $niveauxValidation;
    
     
    public function __construct() {
        
        $this->cocontractants = new ArrayCollection();
        $this->modalitesFinancieres = new ArrayCollection();
    }
    
    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set entiteInitiatrice
     *
     * @param string $entiteInitiatrice
     *
     * @return Contrat
     */
    public function setEntiteInitiatrice($entiteInitiatrice)
    {
        $this->entiteInitiatrice = $entiteInitiatrice;

        return $this;
    }

    /**
     * Get entiteInitiatrice
     *
     * @return string
     */
    public function getEntiteInitiatrice()
    {
        return $this->entiteInitiatrice;
    }

    /**
     * Set codeChrono
     *
     * @param string $codeChrono
     *
     * @return Contrat
     */
    public function setCodeChrono($codeChrono)
    {
        $this->codeChrono = $codeChrono;

        return $this;
    }

    /**
     * Get codeChrono
     *
     * @return string
     */
    public function getCodeChrono()
    {
        return $this->codeChrono;
    }

    /**
     * Set dateOuverture
     *
     * @param \DateTime $dateOuverture
     *
     * @return Contrat
     */
    public function setDateOuverture($dateOuverture)
    {
        $this->dateOuverture = $dateOuverture;

        return $this;
    }

    /**
     * Get dateOuverture
     *
     * @return \DateTime
     */
    public function getDateOuverture()
    {
        return $this->dateOuverture;
    }

    /**
     * Set typeContrat
     *
     * @param \AppBundle\Entity\TypeContrat $typeContrat
     *
     * @return Contrat
     */
    public function setTypeContrat(\AppBundle\Entity\TypeContrat $typeContrat = null)
    {
        $this->typeContrat = $typeContrat;

        return $this;
    }

    /**
     * Get typeContrat
     *
     * @return \AppBundle\Entity\TypeContrat
     */
    public function getTypeContrat()
    {
        return $this->typeContrat;
    }

    /**
     * Set direction
     *
     * @param \AppBundle\Entity\Direction $direction
     *
     * @return Contrat
     */
    public function setDirection(\AppBundle\Entity\Direction $direction = null)
    {
        $this->direction = $direction;

        return $this;
    }

    /**
     * Get direction
     *
     * @return \AppBundle\Entity\Direction
     */
    public function getDirection()
    {
        return $this->direction;
    }

    /**
     * Add cocontractant
     *
     * @param \AppBundle\Entity\Cocontractant $cocontractant
     *
     * @return Contrat
     */
    public function addCocontractant(\AppBundle\Entity\Cocontractant $cocontractant)
    {
        $this->cocontractants[] = $cocontractant;

        return $this;
    }

    /**
     * Remove cocontractant
     *
     * @param \AppBundle\Entity\Cocontractant $cocontractant
     */
    public function removeCocontractant(\AppBundle\Entity\Cocontractant $cocontractant)
    {
        $this->cocontractants->removeElement($cocontractant);
    }

    /**
     * Get cocontractants
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getCocontractants()
    {
        return $this->cocontractants;
    }

    /**
     * Add modalitesFinanciere
     *
     * @param \AppBundle\Entity\ModaliteFinanciere $modalitesFinanciere
     *
     * @return Contrat
     */
    public function addModalitesFinanciere(\AppBundle\Entity\ModaliteFinanciere $modalitesFinanciere)
    {
        $this->modalitesFinancieres[] = $modalitesFinanciere;

        return $this;
    }

    /**
     * Remove modalitesFinanciere
     *
     * @param \AppBundle\Entity\ModaliteFinanciere $modalitesFinanciere
     */
    public function removeModalitesFinanciere(\AppBundle\Entity\ModaliteFinanciere $modalitesFinanciere)
    {
        $this->modalitesFinancieres->removeElement($modalitesFinanciere);
    }

    /**
     * Get modalitesFinancieres
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getModalitesFinancieres()
    {
        return $this->modalitesFinancieres;
    }

    /**
     * Set dureeContrat
     *
     * @param integer $dureeContrat
     *
     * @return Contrat
     */
    public function setDureeContrat($dureeContrat)
    {
        $this->dureeContrat = $dureeContrat;

        return $this;
    }

    /**
     * Get dureeContrat
     *
     * @return integer
     */
    public function getDureeContrat()
    {
        return $this->dureeContrat;
    }

    /**
     * Set preavis
     *
     * @param integer $preavis
     *
     * @return Contrat
     */
    public function setPreavis($preavis)
    {
        $this->preavis = $preavis;

        return $this;
    }

    /**
     * Get preavis
     *
     * @return integer
     */
    public function getPreavis()
    {
        return $this->preavis;
    }

    /**
     * Set taciteReconduction
     *
     * @param string $taciteReconduction
     *
     * @return Contrat
     */
    public function setTaciteReconduction($taciteReconduction)
    {
        $this->taciteReconduction = $taciteReconduction;

        return $this;
    }

    /**
     * Get taciteReconduction
     *
     * @return string
     */
    public function getTaciteReconduction()
    {
        return $this->taciteReconduction;
    }

    /**
     * Set document
     *
     * @param string $document
     *
     * @return Contrat
     */
    public function setDocument($document)
    {
        $this->document = $document;

        return $this;
    }

    /**
     * Get document
     *
     * @return string
     */
    public function getDocument()
    {
        return $this->document;
    }

    /**
     * Add document
     *
     * @param \AppBundle\Entity\Document $document
     *
     * @return Contrat
     */
    public function addDocument(\AppBundle\Entity\Document $document)
    {
        $this->documents[] = $document;

        return $this;
    }

    /**
     * Remove document
     *
     * @param \AppBundle\Entity\Document $document
     */
    public function removeDocument(\AppBundle\Entity\Document $document)
    {
        $this->documents->removeElement($document);
    }

    /**
     * Get documents
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getDocuments()
    {
        return $this->documents;
    }
    
    function getFichier() {
        return $this->fichier;
    }

    function setFichier($fichier) {
        $this->fichier = $fichier;
    }

            

    /**
     * Set objet
     *
     * @param string $objet
     *
     * @return Contrat
     */
    public function setObjet($objet)
    {
        $this->objet = $objet;

        return $this;
    }

    /**
     * Get objet
     *
     * @return string
     */
    public function getObjet()
    {
        return $this->objet;
    }

    /**
     * Set dateSignature
     *
     * @param \DateTime $dateSignature
     *
     * @return Contrat
     */
    public function setDateSignature($dateSignature)
    {
        $this->dateSignature = $dateSignature;

        return $this;
    }

    /**
     * Get dateSignature
     *
     * @return \DateTime
     */
    public function getDateSignature()
    {
        return $this->dateSignature;
    }

    /**
     * Set datePriseEffet
     *
     * @param \DateTime $datePriseEffet
     *
     * @return Contrat
     */
    public function setDatePriseEffet($datePriseEffet)
    {
        $this->datePriseEffet = $datePriseEffet;

        return $this;
    }

    /**
     * Get datePriseEffet
     *
     * @return \DateTime
     */
    public function getDatePriseEffet()
    {
        return $this->datePriseEffet;
    }

    /**
     * Set dateEcheance
     *
     * @param \DateTime $dateEcheance
     *
     * @return Contrat
     */
    public function setDateEcheance($dateEcheance)
    {
        $this->dateEcheance = $dateEcheance;

        return $this;
    }

    /**
     * Get dateEcheance
     *
     * @return \DateTime
     */
    public function getDateEcheance()
    {
        return $this->dateEcheance;
    }

    /**
     * Set dateResiliation
     *
     * @param \DateTime $dateResiliation
     *
     * @return Contrat
     */
    public function setDateResiliation($dateResiliation)
    {
        $this->dateResiliation = $dateResiliation;

        return $this;
    }

    /**
     * Get dateResiliation
     *
     * @return \DateTime
     */
    public function getDateResiliation()
    {
        return $this->dateResiliation;
    }

    /**
     * Set etat
     *
     * @param integer $etat
     *
     * @return Contrat
     */
    public function setEtat($etat)
    {
        $this->etat = $etat;

        return $this;
    }

    /**
     * Get etat
     *
     * @return integer
     */
    public function getEtat()
    {
        return $this->etat;
    }
    
    /**
     * Add historiquesAction
     *
     * @param \AppBundle\Entity\HistoriqueActionContrat $historiquesAction
     *
     * @return Contrat
     */
    public function addHistoriquesAction(\AppBundle\Entity\HistoriqueActionContrat $historiquesAction)
    {
        $this->historiquesActions[] = $historiquesAction;

        return $this;
    }

    /**
     * Remove historiquesAction
     *
     * @param \AppBundle\Entity\HistoriqueActionContrat $historiquesAction
     */
    public function removeHistoriquesAction(\AppBundle\Entity\HistoriqueActionContrat $historiquesAction)
    {
        $this->historiquesActions->removeElement($historiquesAction);
    }

    /**
     * Get historiquesActions
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getHistoriquesActions()
    {
        return $this->historiquesActions;
    }

    /**
     * Set username
     *
     * @param string $username
     *
     * @return Contrat
     */
    public function setUsername($username)
    {
        $this->username = $username;

        return $this;
    }

    /**
     * Get username
     *
     * @return string
     */
    public function getUsername()
    {
        return $this->username;
    }
    
    

    /**
     * Set nomInitiateur
     *
     * @param string $nomInitiateur
     *
     * @return Contrat
     */
    public function setNomInitiateur($nomInitiateur)
    {
        $this->nomInitiateur = $nomInitiateur;

        return $this;
    }

    /**
     * Get nomInitiateur
     *
     * @return string
     */
    public function getNomInitiateur()
    {
        return $this->nomInitiateur;
    }

    /**
     * Add niveauxValidation
     *
     * @param \AppBundle\Entity\NiveauValidation $niveauxValidation
     *
     * @return Contrat
     */
    public function addNiveauxValidation(\AppBundle\Entity\NiveauValidation $niveauxValidation)
    {
        $this->niveauxValidation[] = $niveauxValidation;

        return $this;
    }

    /**
     * Remove niveauxValidation
     *
     * @param \AppBundle\Entity\NiveauValidation $niveauxValidation
     */
    public function removeNiveauxValidation(\AppBundle\Entity\NiveauValidation $niveauxValidation)
    {
        $this->niveauxValidation->removeElement($niveauxValidation);
    }

    /**
     * Get niveauxValidation
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getNiveauxValidation()
    {
        return $this->niveauxValidation;
    }
}
