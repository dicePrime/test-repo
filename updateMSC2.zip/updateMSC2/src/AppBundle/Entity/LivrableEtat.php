<?php

//src/AppBundle/Entity/Role.php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Description of Contract
 *
 * @author ndziePatrick
 * 
 * @ORM\Entity
 * @ORM\Table(name="livrable_etat")
 */
class LivrableEtat {
    //put your code here
        
    /**
     *
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;                        
       
    /**
     *
     * @ORM\Column(type="string", length=5)
     */
    private $requis;
    
    /**
     * Ce champ indique si le livrable peut être présent en plusieurs
     * examplaires, c'est un champ crée pour 
     * le type fichier
     * @ORM\Column(type="string", length= 5)
     */
    private $multiple;
    
    /**
     *
     * @ORM\Column(type="string", length = 255)
     */
    private $type;
    
     /**
     *
     * @ORM\Column(type="string", length = 255)
     */
    private $nom;
    
    /**
     * Plusieurs livrables peuvent avoir le même type
     * @ORM\ManyToOne(targetEntity="Etat")
     * @ORM\JoinColumn(name="etat_livrable_etat", referencedColumnName="id")
     */
    private $etat;
    
    

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set requis
     *
     * @param string $requis
     *
     * @return LivrableEtat
     */
    public function setRequis($requis)
    {
        $this->requis = $requis;

        return $this;
    }

    /**
     * Get requis
     *
     * @return string
     */
    public function getRequis()
    {
        return $this->requis;
    }

    /**
     * Set multiple
     *
     * @param string $multiple
     *
     * @return LivrableEtat
     */
    public function setMultiple($multiple)
    {
        $this->multiple = $multiple;

        return $this;
    }

    /**
     * Get multiple
     *
     * @return string
     */
    public function getMultiple()
    {
        return $this->multiple;
    }

    /**
     * Set type
     *
     * @param string $type
     *
     * @return LivrableEtat
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set etat
     *
     * @param \AppBundle\Entity\Etat $etat
     *
     * @return LivrableEtat
     */
    public function setEtat(\AppBundle\Entity\Etat $etat = null)
    {
        $this->etat = $etat;

        return $this;
    }

    /**
     * Get etat
     *
     * @return \AppBundle\Entity\Etat
     */
    public function getEtat()
    {
        return $this->etat;
    }

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return LivrableEtat
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }
}
