<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Description of NiveauWorkflowBase
 *
 * @author ndziePatrick
 * 
 * 
 * @ORM\Entity
 * @ORM\Table(name="niveau_workflow_base")
 */
class NiveauWorkflowBase {
    //put your code here
    
    /**
     *
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;                        
       
     /**
     * Plusieurs livrables peuvent avoir le même type
     * @ORM\ManyToOne(targetEntity="TypeContrat", inversedBy = "niveaux")
     * @ORM\JoinColumn(name="niveau_workflow_type_contrat", referencedColumnName="id")
     */
    private $typeContrat;
    
    /**
     * @ORM\Column(type="integer")
     */
    private $niveau;
    
        
    /**
     * Plusieurs livrables peuvent avoir le même type
     * @ORM\ManyToOne(targetEntity="Etat")
     * @ORM\JoinColumn(name="niveau_workflow_etat", referencedColumnName="id")
     */
    private $etat;    
    

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set niveau
     *
     * @param integer $niveau
     *
     * @return NiveauWorkflowBase
     */
    public function setNiveau($niveau)
    {
        $this->niveau = $niveau;

        return $this;
    }

    /**
     * Get niveau
     *
     * @return integer
     */
    public function getNiveau()
    {
        return $this->niveau;
    }

    /**
     * Set typeContrat
     *
     * @param \AppBundle\Entity\TypeContrat $typeContrat
     *
     * @return NiveauWorkflowBase
     */
    public function setTypeContrat(\AppBundle\Entity\TypeContrat $typeContrat = null)
    {
        $this->typeContrat = $typeContrat;

        return $this;
    }

    /**
     * Get typeContrat
     *
     * @return \AppBundle\Entity\TypeContrat
     */
    public function getTypeContrat()
    {
        return $this->typeContrat;
    }

    /**
     * Set etat
     *
     * @param \AppBundle\Entity\Etat $etat
     *
     * @return NiveauWorkflowBase
     */
    public function setEtat(\AppBundle\Entity\Etat $etat = null)
    {
        $this->etat = $etat;

        return $this;
    }

    /**
     * Get etat
     *
     * @return \AppBundle\Entity\Etat
     */
    public function getEtat()
    {
        return $this->etat;
    }
}
