<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Description of Contract
 *
 * @author ndziePatrick
 * 
 * @ORM\Entity
 * @ORM\Table(name="type_adresse")
 */
class TypeAdresse {
    //put your code here
    /**
     *
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;
                        
    /**
     *
     * @ORM\Column(type="string", length=255)
     * @var string
     */
    private $nom;  
    
    /**
     * Un type de contrat peut avoir plusieurs instances
     * @ORM\OneToMany(targetEntity="Adresse", mappedBy="type")
     */
    private $adresses;

    
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->adresses = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return TypeAdresse
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Add adress
     *
     * @param \AppBundle\Entity\Adresse $adress
     *
     * @return TypeAdresse
     */
    public function addAdress(\AppBundle\Entity\Adresse $adress)
    {
        $this->adresses[] = $adress;

        return $this;
    }

    /**
     * Remove adress
     *
     * @param \AppBundle\Entity\Adresse $adress
     */
    public function removeAdress(\AppBundle\Entity\Adresse $adress)
    {
        $this->adresses->removeElement($adress);
    }

    /**
     * Get adresses
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAdresses()
    {
        return $this->adresses;
    }
}
