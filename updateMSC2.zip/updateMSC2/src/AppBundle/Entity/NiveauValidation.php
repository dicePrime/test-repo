<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Description of NPlus1Contrat
 * Cette table stocke la liste des n+1 
 * de l'utilisateur qui a crée un contrat
 * 
 * @author ndziePatrick
 * 
 * @ORM\Entity
 * @ORM\Table(name="niveau_validation")
 */
class NiveauValidation {
    //put your code here
        
    /**
     *
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;  
    
    
    /**
     * Plusieurs livrables peuvent avoir le même type
     * @ORM\ManyToOne(targetEntity="Contrat", inversedBy = "niveauxValidation")
     * @ORM\JoinColumn(name="niveau_validation_contrat", referencedColumnName="id")
     */
    private $contrat;
    
    
    /**
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $dateValidation;
    
    /**
     *
     * @ORM\Column(type="text", nullable=true)
     */
    private $commentaire;
    
    /**
     *
     * @ORM\Column(type="string", length=10, nullable=true)
     */
    private $decision;
    
    /**
     * Plusieurs livrables peuvent avoir le même type
     * @ORM\ManyToOne(targetEntity="Etat")
     * @ORM\JoinColumn(name="niveau_validation_etat", referencedColumnName="id")
     */
    private $etat; 
    
    /**
     *
     * Un cocontractant peut avoir plusieurs adresses
     * 
     * @ORM\OneToMany(targetEntity="LivrableNiveauValidation", mappedBy="NiveauValidation", cascade={"persist", "remove"})
     */
    private $livrables;
    
    /**
     *
     * @ORM\Column(type="string", length=64)
     */
    private $statut = "PENDING";
    
    /**
     * @ORM\Column(type="integer")
     */
    private $niveau;
    
    
    
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->livrables = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set dateValidation
     *
     * @param \DateTime $dateValidation
     *
     * @return NiveauValidation
     */
    public function setDateValidation($dateValidation)
    {
        $this->dateValidation = $dateValidation;

        return $this;
    }

    /**
     * Get dateValidation
     *
     * @return \DateTime
     */
    public function getDateValidation()
    {
        return $this->dateValidation;
    }

    /**
     * Set commentaire
     *
     * @param string $commentaire
     *
     * @return NiveauValidation
     */
    public function setCommentaire($commentaire)
    {
        $this->commentaire = $commentaire;

        return $this;
    }

    /**
     * Get commentaire
     *
     * @return string
     */
    public function getCommentaire()
    {
        return $this->commentaire;
    }

    /**
     * Set decision
     *
     * @param string $decision
     *
     * @return NiveauValidation
     */
    public function setDecision($decision)
    {
        $this->decision = $decision;

        return $this;
    }

    /**
     * Get decision
     *
     * @return string
     */
    public function getDecision()
    {
        return $this->decision;
    }

    /**
     * Set statut
     *
     * @param string $statut
     *
     * @return NiveauValidation
     */
    public function setStatut($statut)
    {
        $this->statut = $statut;

        return $this;
    }

    /**
     * Get statut
     *
     * @return string
     */
    public function getStatut()
    {
        return $this->statut;
    }

   

    /**
     * Set etat
     *
     * @param \AppBundle\Entity\Etat $etat
     *
     * @return NiveauValidation
     */
    public function setEtat(\AppBundle\Entity\Etat $etat = null)
    {
        $this->etat = $etat;

        return $this;
    }

    /**
     * Get etat
     *
     * @return \AppBundle\Entity\Etat
     */
    public function getEtat()
    {
        return $this->etat;
    }

    /**
     * Add livrable
     *
     * @param \AppBundle\Entity\LivrableNiveauValidation $livrable
     *
     * @return NiveauValidation
     */
    public function addLivrable(\AppBundle\Entity\LivrableNiveauValidation $livrable)
    {
        $this->livrables[] = $livrable;

        return $this;
    }

    /**
     * Remove livrable
     *
     * @param \AppBundle\Entity\LivrableNiveauValidation $livrable
     */
    public function removeLivrable(\AppBundle\Entity\LivrableNiveauValidation $livrable)
    {
        $this->livrables->removeElement($livrable);
    }

    /**
     * Get livrables
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getLivrables()
    {
        return $this->livrables;
    }

    /**
     * Set contrat
     *
     * @param \AppBundle\Entity\Contrat $contrat
     *
     * @return NiveauValidation
     */
    public function setContrat(\AppBundle\Entity\Contrat $contrat = null)
    {
        $this->contrat = $contrat;

        return $this;
    }

    /**
     * Get contrat
     *
     * @return \AppBundle\Entity\Contrat
     */
    public function getContrat()
    {
        return $this->contrat;
    }

    /**
     * Set niveau
     *
     * @param integer $niveau
     *
     * @return NiveauValidation
     */
    public function setNiveau($niveau)
    {
        $this->niveau = $niveau;

        return $this;
    }

    /**
     * Get niveau
     *
     * @return integer
     */
    public function getNiveau()
    {
        return $this->niveau;
    }
}
