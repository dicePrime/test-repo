<?php

//src/AppBundle/Entity/Contrat.php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * Description of Contract
 *
 * @author ndziePatrick
 * 
 * @ORM\Entity
 * @ORM\Table(name="cocontractant")
 */
class Cocontractant {
    //put your code here    

    /**
     *
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     *
     * @ORM\Column(type="string", length=255)
     * @var string
     */
    private $nom;

    /**
     *
     * @ORM\Column(type="text")
     * @var string
     */
    private $description;

    /**
     *
     * Un cocontractant peut avoir plusieurs adresses
     * 
     * @ORM\OneToMany(targetEntity="Adresse", mappedBy="cocontractant")
     */
    private $adresses;
    
    /**
     * Plusieurs Cocontractants peuvent avoir plusieurs contrats.
     * @ORM\ManyToMany(targetEntity="Contrat", mappedBy="cocontractants")
     */
    private $contrats;

   

    public function __construct() 
    {
        $this->adresses = new ArrayCollection();
        $this->contrats = new ArrayCollection();
    }

    


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return Cocontractant
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Cocontractant
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Add adress
     *
     * @param \AppBundle\Entity\Adresse $adress
     *
     * @return Cocontractant
     */
    public function addAdress(\AppBundle\Entity\Adresse $adress)
    {
        $adress->setCocontractant($this);
        $this->adresses[] = $adress;

        return $this;
    }

    /**
     * Remove adress
     *
     * @param \AppBundle\Entity\Adresse $adress
     */
    public function removeAdress(\AppBundle\Entity\Adresse $adress)
    {
        $this->adresses->removeElement($adress);
    }

    /**
     * Get adresses
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAdresses()
    {
        return $this->adresses;
    }
    
    public function setAdresses($adresses)
    {
        foreach($adresses as $adresse)
        {
            $adresse->setCocontractant($this);
        }
        
        $this->adresses = $adresses;
    }

    /**
     * Add contrat
     *
     * @param \AppBundle\Entity\Contrat $contrat
     *
     * @return Cocontractant
     */
    public function addContrat(\AppBundle\Entity\Contrat $contrat)
    {
        $this->contrats[] = $contrat;

        return $this;
    }

    /**
     * Remove contrat
     *
     * @param \AppBundle\Entity\Contrat $contrat
     */
    public function removeContrat(\AppBundle\Entity\Contrat $contrat)
    {
        $this->contrats->removeElement($contrat);
    }

    /**
     * Get contrats
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getContrats()
    {
        return $this->contrats;
    }
}
