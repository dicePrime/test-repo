<?php

//src/AppBundle/Entity/Role.php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Description of Contract
 *
 * @author ndziePatrick
 * 
 * @ORM\Entity
 * @ORM\Table(name="etat")
 */
class Etat {
    //put your code here
        
    /**
     *
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;
                        
    /**
     *
     * @ORM\Column(type="string", length=255)
     * @var string
     */
    private $nom;  
        
    /**
     *
     * @ORM\Column(type="text")
     */
    private $description; 
    
    
    /**
     *
     * Un cocontractant peut avoir plusieurs adresses
     * 
     * @ORM\OneToMany(targetEntity="LivrableEtat", mappedBy="etat", cascade={"persist", "remove"})
     */
    private $livrables;
    
    /**
     *
     * Plusieurs etat peuvent avoir plusieurs rôles qui les 
     * valident
     * @ORM\ManyToMany(targetEntity="Role")
     * @ORM\JoinTable(name="etat_roles",
     *  joinColumns={@ORM\JoinColumn(name="etat_id", referencedColumnName="id")},
     *  inverseJoinColumns={@ORM\JoinColumn(name="role_id", referencedColumnName="id")})
     */
    private $roles;

    
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->livrables = new \Doctrine\Common\Collections\ArrayCollection();
        $this->roles = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return Etat
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Etat
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Add livrable
     *
     * @param \AppBundle\Entity\LivrableEtat $livrable
     *
     * @return Etat
     */
    public function addLivrable(\AppBundle\Entity\LivrableEtat $livrable)
    {
        $this->livrables[] = $livrable;

        return $this;
    }

    /**
     * Remove livrable
     *
     * @param \AppBundle\Entity\LivrableEtat $livrable
     */
    public function removeLivrable(\AppBundle\Entity\LivrableEtat $livrable)
    {
        $this->livrables->removeElement($livrable);
    }

    /**
     * Get livrables
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getLivrables()
    {
        return $this->livrables;
    }

    /**
     * Add role
     *
     * @param \AppBundle\Entity\Role $role
     *
     * @return Etat
     */
    public function addRole(\AppBundle\Entity\Role $role)
    {
        $this->roles[] = $role;

        return $this;
    }

    /**
     * Remove role
     *
     * @param \AppBundle\Entity\Role $role
     */
    public function removeRole(\AppBundle\Entity\Role $role)
    {
        $this->roles->removeElement($role);
    }

    /**
     * Get roles
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getRoles()
    {
        return $this->roles;
    }
}
