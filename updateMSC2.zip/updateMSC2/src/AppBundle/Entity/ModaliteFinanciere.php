<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Description of Contract
 *
 * @author ndziePatrick
 * 
 * @ORM\Entity
 * @ORM\Table(name="modalite_financiere")
 */
class ModaliteFinanciere {
    //put your code here
    /**
     *
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;
                        
    /**
     *
     * @ORM\Column(type="string", length=255)
     * @var string
     */
    private $nom;  
        
    /**
     *
     * @ORM\Column(type="text")
     */
    private $description;
    
     /**
     *
     * @ORM\Column(type="float")
     */
    private $montant;
    
    
     /**
     * 
     * @ORM\ManyToOne(targetEntity="Contrat", inversedBy="modalitesFinancieres")
     * @ORM\JoinColumn(name="contrat_id", referencedColumnName="id", onDelete="CASCADE", nullable=false)
     */
    private $contrat;

   

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return ModaliteFinanciere
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return ModaliteFinanciere
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set montant
     *
     * @param float $montant
     *
     * @return ModaliteFinanciere
     */
    public function setMontant($montant)
    {
        $this->montant = $montant;

        return $this;
    }

    /**
     * Get montant
     *
     * @return float
     */
    public function getMontant()
    {
        return $this->montant;
    }


    /**
     * Set contrat
     *
     * @param \AppBundle\Entity\Contrat $contrat
     *
     * @return ModaliteFinanciere
     */
    public function setContrat(\AppBundle\Entity\Contrat $contrat)
    {
        $this->contrat = $contrat;

        return $this;
    }

    /**
     * Get contrat
     *
     * @return \AppBundle\Entity\Contrat
     */
    public function getContrat()
    {
        return $this->contrat;
    }
}
