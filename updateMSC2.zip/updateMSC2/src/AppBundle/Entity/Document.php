<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Description of Contract
 *
 * @author ndziePatrick
 * 
 * @ORM\Entity
 * @ORM\Table(name="document")
 */
class Document {
    //put your code here
    /**
     *
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;
                        
    /**
     *
     * @ORM\Column(type="string", length=255)
     * @var string
     */
    private $nom;  
        
    /**
     *
     * @ORM\Column(type="string", length=255)
     */
    private $chemin; 
    
    /**
     *
     * @ORM\ManyToOne(targetEntity="Contrat", inversedBy="documents")
     * @ORM\JoinColumn(name="id_contrat", referencedColumnName="id")
     */
    private $contrat;
    
     /**
     * Plusieurs adresse peuvent avoir le même type
     * @ORM\ManyToOne(targetEntity="TypeDocument")
     * @ORM\JoinColumn(name="type_document_id", referencedColumnName="id")
     */
    private $type;
    
    
    /**
     * 
     * @Assert\File()
     */
    private $fichier;
    
                

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return Document
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set chemin
     *
     * @param string $chemin
     *
     * @return Document
     */
    public function setChemin($chemin)
    {
        $this->chemin = $chemin;

        return $this;
    }

    /**
     * Get chemin
     *
     * @return string
     */
    public function getChemin()
    {
        return $this->chemin;
    }

    /**
     * Set contrat
     *
     * @param \AppBundle\Entity\Contrat $contrat
     *
     * @return Document
     */
    public function setContrat(\AppBundle\Entity\Contrat $contrat = null)
    {
        $this->contrat = $contrat;

        return $this;
    }

    /**
     * Get contrat
     *
     * @return \AppBundle\Entity\Contrat
     */
    public function getContrat()
    {
        return $this->contrat;
    }

    /**
     * Set type
     *
     * @param \AppBundle\Entity\TypeDocument $type
     *
     * @return Document
     */
    public function setType(\AppBundle\Entity\TypeDocument $type = null)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return \AppBundle\Entity\TypeDocument
     */
    public function getType()
    {
        return $this->type;
    }
    
    function getFichier() {
        return $this->fichier;
    }

    function setFichier($fichier) {
        $this->fichier = $fichier;
    }

    public function __toString() {
        
        return "Id:".$this->id."Nom".$this->nom."chemin:".$this->chemin."type:".$this->type->getId();
    }

}
