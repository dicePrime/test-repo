<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Description of HistoriqueAction
 *
 * @author BMHB8456
 */
class HistoriqueAction {
    //put your code here
    
      /**
     *
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
      protected $id;
                        
    /**
     *
     * @ORM\Column(type="string", length=255)
     * @var string
     */
    protected $nom;
    
    
    /**
     *
     * @ORM\Column(type="text", nullable=true)
     */
    protected $description;
    
    
    /**
     *
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    protected $username;
    
    /**
     *
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    protected $nomUser;
    
    /**
     *
     * @ORM\Column(type="datetime")
     */
    protected $dateAction;
    
    function getId() {
        return $this->id;
    }

    function getNom() {
        return $this->nom;
    }

    function getDescription() {
        return $this->description;
    }

    function getUsername() {
        return $this->username;
    }

    function getNomUser() {
        return $this->nomUser;
    }

    function getDateAction() {
        return $this->dateAction;
    }

    
    function setNom($nom) {
        $this->nom = $nom;
    }

    function setDescription($description) {
        $this->description = $description;
    }

    function setUsername($username) {
        $this->username = $username;
    }

    function setNomUser($nomUser) {
        $this->nomUser = $nomUser;
    }

    function setDateAction($dateAction) {
        $this->dateAction = $dateAction;
    }

   
    
    
}
