<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Description of NPlus1Contrat
 * Cette table stocke la liste des n+1 
 * de l'utilisateur qui a crée un contrat
 * 
 * @author ndziePatrick
 * 
 * @ORM\Entity
 * @ORM\Table(name="n_plus_1_contrat")
 */
class NPlus1Contrat {
    //put your code here
    
    /**
     *
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;    
    
    /**
     * 
     * @ORM\ManyToOne(targetEntity="Contrat", inversedBy="nplus1")
     * @ORM\JoinColumn(name="contrat_id", referencedColumnName="id", onDelete="CASCADE", nullable=false)
     */
    private $contrat;
    
    /**
     *
     * @ORM\Column(type="string", length=64)
     */
    private $matricule;
    
    /**
     *
     * @ORM\Column(type="string", length=64)
     */
    private $cuid;
    
    
    /**
     *
     * @ORM\Column(type="string", length=64)
     */
    private $email;
    
    
    
    
    

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set matricule
     *
     * @param string $matricule
     *
     * @return NPlus1Contrat
     */
    public function setMatricule($matricule)
    {
        $this->matricule = $matricule;

        return $this;
    }

    /**
     * Get matricule
     *
     * @return string
     */
    public function getMatricule()
    {
        return $this->matricule;
    }

    /**
     * Set cuid
     *
     * @param string $cuid
     *
     * @return NPlus1Contrat
     */
    public function setCuid($cuid)
    {
        $this->cuid = $cuid;

        return $this;
    }

    /**
     * Get cuid
     *
     * @return string
     */
    public function getCuid()
    {
        return $this->cuid;
    }

    /**
     * Set email
     *
     * @param string $email
     *
     * @return NPlus1Contrat
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set contrat
     *
     * @param \AppBundle\Entity\Contrat $contrat
     *
     * @return NPlus1Contrat
     */
    public function setContrat(\AppBundle\Entity\Contrat $contrat)
    {
        $this->contrat = $contrat;

        return $this;
    }

    /**
     * Get contrat
     *
     * @return \AppBundle\Entity\Contrat
     */
    public function getContrat()
    {
        return $this->contrat;
    }
}
