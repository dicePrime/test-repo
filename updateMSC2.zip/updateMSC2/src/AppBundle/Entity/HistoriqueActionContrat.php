<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Description of Contract
 *
 * @author ndziePatrick
 * 
 * @ORM\Entity
 * @ORM\Table(name="historique_action_contrat")
 */
class HistoriqueActionContrat extends HistoriqueAction {
    //put your code here
    
  
    
    /**
     * 
     * @ORM\ManyToOne(targetEntity="Contrat", inversedBy="historiquesActions")
     * @ORM\JoinColumn(name="contrat_id", referencedColumnName="id")
     */
    protected $contrat;  
    
    
    

    /**
     * Set contrat
     *
     * @param \AppBundle\Entity\Contrat $contrat
     *
     * @return HistoriqueActionContrat
     */
    public function setContrat(\AppBundle\Entity\Contrat $contrat = null)
    {
        $this->contrat = $contrat;

        return $this;
    }

    /**
     * Get contrat
     *
     * @return \AppBundle\Entity\Contrat
     */
    public function getContrat()
    {
        return $this->contrat;
    }
}
