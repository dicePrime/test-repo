<?php

//src/AppBundle/Entity/Contrat.php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Description of Contract
 *
 * @author ndziePatrick
 * 
 * @ORM\Entity
 * @ORM\Table(name="type_contrat")
 */
class TypeContrat 
{
    //put your code here    
    
    /**
     *
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;    
      
    /**
     *
     * @ORM\Column(type="string", length=255)
     */
    private $nom;
        
    /**
     *
     * @ORM\Column(type="text")
     */
    private $description;   
    
    /**
     *
     * @ORM\Column(type="string", length=255)
     * 
     */
    private $modele;
    
    
    /**
     * 
     * @Assert\File()
     */
    private $template;
    
    
    /**
     * Un type de contrat peut avoir plusieurs instances
     * @ORM\OneToMany(targetEntity="Contrat", mappedBy="typeContrat")
     */
    private $contrats;
    
    /**
     * Un type de contrat peut avoir plusieurs instances
     * @ORM\OneToMany(targetEntity="NiveauWorkflowBase", mappedBy="typeContrat")
     */
    private $niveaux;
    
   
    private $typesDocuments;
    
    public function __construct() 
    {
        
        $this->typesDocuments = new ArrayCollection();
        $this->contrats = new ArrayCollection();
        $this->niveaux = new ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return TypeContrat
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Add contrat
     *
     * @param \AppBundle\Entity\Contrat $contrat
     *
     * @return TypeContrat
     */
    public function addContrat(\AppBundle\Entity\Contrat $contrat)
    {
        $this->contrats[] = $contrat;

        return $this;
    }

    /**
     * Remove contrat
     *
     * @param \AppBundle\Entity\Contrat $contrat
     */
    public function removeContrat(\AppBundle\Entity\Contrat $contrat)
    {
        $this->contrats->removeElement($contrat);
    }

    /**
     * Get contrats
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getContrats()
    {
        return $this->contrats;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return TypeContrat
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set modele
     *
     * @param string $modele
     *
     * @return TypeContrat
     */
    public function setModele($modele)
    {
        $this->modele = $modele;

        return $this;
    }

    /**
     * Get modele
     *
     * @return string
     */
    public function getModele()
    {
        return $this->modele;
    }

    /**
     * Add niveaux
     *
     * @param \AppBundle\Entity\NiveauWorkflowBase $niveaux
     *
     * @return TypeContrat
     */
    public function addNiveaux(\AppBundle\Entity\NiveauWorkflowBase $niveaux)
    {
        $this->niveaux[] = $niveaux;

        return $this;
    }

    /**
     * Remove niveaux
     *
     * @param \AppBundle\Entity\NiveauWorkflowBase $niveaux
     */
    public function removeNiveaux(\AppBundle\Entity\NiveauWorkflowBase $niveaux)
    {
        $this->niveaux->removeElement($niveaux);
    }

    /**
     * Get niveaux
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getNiveaux()
    {
        return $this->niveaux;
    }
    
    function getTemplate() {
        return $this->template;
    }

    function getTypesDocuments() {
        return $this->typesDocuments;
    }

    function setTemplate($template) {
        $this->template = $template;
    }

    function setTypesDocuments($typesDocuments) {
        $this->typesDocuments = $typesDocuments;
    }


}
