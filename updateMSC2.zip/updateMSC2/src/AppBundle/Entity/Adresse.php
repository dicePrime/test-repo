<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Description of Profile
 *
 * @author ndziePatrick
 * 
 * @ORM\Entity
 * @ORM\Table(name="adresse")
 */
class Adresse {
    //put your code here
    //put your code here
        
    /**
     *
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;
                        
    /**
     *
     * @ORM\Column(type="string", length=255)
     * @var string
     */
    private $adresse;        
    
    /**
     * Plusieurs adresse peuvent avoir le même type
     * @ORM\ManyToOne(targetEntity="TypeAdresse")
     * @ORM\JoinColumn(name="type_adresse_id", referencedColumnName="id")
     */
    private $type;
    
    /**
     * 
     * @ORM\ManyToOne(targetEntity="Cocontractant", inversedBy="adresses")
     * @ORM\JoinColumn(name="cocontractant_id", referencedColumnName="id", onDelete="CASCADE", nullable=false)
     */
    private $cocontractant;  
    

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set adresse
     *
     * @param string $adresse
     *
     * @return Adresse
     */
    public function setAdresse($adresse)
    {
        $this->adresse = $adresse;

        return $this;
    }

    /**
     * Get adresse
     *
     * @return string
     */
    public function getAdresse()
    {
        return $this->adresse;
    }

    /**
     * Set type
     *
     * @param \AppBundle\Entity\TypeAdresse $type
     *
     * @return Adresse
     */
    public function setType(\AppBundle\Entity\TypeAdresse $type = null)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return \AppBundle\Entity\TypeAdresse
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set cocontractant
     *
     * @param \AppBundle\Entity\Cocontractant $cocontractant
     *
     * @return Adresse
     */
    public function setCocontractant(\AppBundle\Entity\Cocontractant $cocontractant = null)
    {
        $this->cocontractant = $cocontractant;

        return $this;
    }

    /**
     * Get cocontractant
     *
     * @return \AppBundle\Entity\Cocontractant
     */
    public function getCocontractant()
    {
        return $this->cocontractant;
    }
}
