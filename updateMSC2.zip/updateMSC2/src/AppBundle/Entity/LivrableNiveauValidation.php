<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;    


/**
 * Description of Contract
 *
 * @author ndziePatrick
 * 
 * @ORM\Entity
 * @ORM\Table(name="livrable_niveau_validation")
 */
class LivrableNiveauValidation {
    //put your code here
    /**
     *
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;
    
    
    /**
     *
     * @ORM\Column(type="string", length=255)
     */
    private $type;
    
    /**
     *
     * @ORM\Column(type="string", length=255)
     */
    private $nom;
    
    /**
     *
     * @ORM\Column(type="string", length=64)
     */
    private $requis;
    
    /**
     *
     * @ORM\Column(type="string", length=255)
     */
    private $statut ="EMPTY";
    
    /**
     *
     * @ORM\Column(type="text", nullable=true) 
     */
    private $valeur;
    
    
     /**
     * Plusieurs livrables peuvent avoir le même type
     * @ORM\ManyToOne(targetEntity="NiveauValidation")
     * @ORM\JoinColumn(name="niveau_validation_livrable", referencedColumnName="id")
     */
    private $NiveauValidation; 

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set type
     *
     * @param string $type
     *
     * @return LivrableNiveauValidation
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return LivrableNiveauValidation
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set requis
     *
     * @param string $requis
     *
     * @return LivrableNiveauValidation
     */
    public function setRequis($requis)
    {
        $this->requis = $requis;

        return $this;
    }

    /**
     * Get requis
     *
     * @return string
     */
    public function getRequis()
    {
        return $this->requis;
    }

    /**
     * Set statut
     *
     * @param string $statut
     *
     * @return LivrableNiveauValidation
     */
    public function setStatut($statut)
    {
        $this->statut = $statut;

        return $this;
    }

    /**
     * Get statut
     *
     * @return string
     */
    public function getStatut()
    {
        return $this->statut;
    }

    /**
     * Set valeur
     *
     * @param string $valeur
     *
     * @return LivrableNiveauValidation
     */
    public function setValeur($valeur)
    {
        $this->valeur = $valeur;

        return $this;
    }

    /**
     * Get valeur
     *
     * @return string
     */
    public function getValeur()
    {
        return $this->valeur;
    }

    /**
     * Set niveauValidation
     *
     * @param \AppBundle\Entity\NiveauValidation $niveauValidation
     *
     * @return LivrableNiveauValidation
     */
    public function setNiveauValidation(\AppBundle\Entity\NiveauValidation $niveauValidation = null)
    {
        $this->NiveauValidation = $niveauValidation;

        return $this;
    }

    /**
     * Get niveauValidation
     *
     * @return \AppBundle\Entity\NiveauValidation
     */
    public function getNiveauValidation()
    {
        return $this->NiveauValidation;
    }
}
