<?php

//src/AppBundle/Entity/Utilisateur.php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\User\EquatableInterface;

/**
 * Description of Contract
 *
 * @author ndziePatrick
 * 
 * @ORM\Entity
 * @ORM\Table(name="user")
 */
class User implements UserInterface, EquatableInterface {
    //put your code here
        
    /**
     * @ORM\Id
     * @ORM\Column(type="string", length=64)
     * @var string
     */
    private $username;        
    
    /**
     *
     * @ORM\Column(type="string", length=255, nullable=true)
     * 
     */
    private $matricule;    
    
    /**
     *
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $nom;
                
    private $password;
    
    private $salt;    
    
    private $roles;
    
    /**
     * Plusieurs contrats ont plusieurs cocontractants.
     * @ORM\ManyToMany(targetEntity="Role", inversedBy="users")
     * @ORM\JoinTable(name="users_roles", 
     * joinColumns={@ORM\JoinColumn(name="user_username", referencedColumnName="username")},
     * inverseJoinColumns={@ORM\JoinColumn(name="role_id", referencedColumnName="id")})
     * 
     */
    private $appRoles;
    
    /**
     *
     * @ORM\Column(type="string", length=64)
     */
    private $direction;
    
    /**
     *
     * @ORM\Column(type="string", length=64)
     */
    private $departement;
    
    /**
     *
     * @ORM\Column(type="string", length=64, nullable=true)
     */
    private $service;
    
    /**
     *
     * @ORM\Column(type="string", length=64, nullable=true)
     */
    private $email;   
    
   
    /**
     *
     * @ORM\Column(type="string", length=64, nullable=true)
     */
    private $profilStaf;
    
    /**
     *
     * @ORM\Column(type="string", length=64, nullable=true)
     */
    private $nature;
    
    /**
     *
     * @ORM\Column(type="string", length=64, nullable=true)
     */
    private $derniereConnexion;  
    

    private $contrats;
                
    public function __construct($username, $password, $salt)
    {
        $this->username = $username;
        $this->password = $password;
        $this->salt = $salt;
        $this->roles = array("ROLE_USER");

    }
    
    function getUsername() {
        return $this->username;
    }

    function getPassword() {
        return $this->password;
    }

    function getSalt() {
        return $this->salt;
    }

    function getRoles() 
    {
        return $this->roles;
    }

    function setUsername($username) {
        $this->username = $username;
    }

    function setPassword($password) {
        $this->password = $password;
    }

    function setSalt($salt) {
        $this->salt = $salt;
    }

    function setRoles($roles) {
        $this->roles = $roles;
    }
    function getMatricule() {
        return $this->matricule;
    }

    function getNom() {
        return $this->nom;
    }

    function getEmail() {
        return $this->email;
    }

    function setMatricule($matricule) {
        $this->matricule = $matricule;
    }

    function setNom($nom) {
        $this->nom = $nom;
    }

    function setEmail($email) {
        $this->email = $email;
    }
    
    function getNomDirection() {
        return $this->nomDirection;
    }

    function setNomDirection($nomDirection) {
        $this->nomDirection = $nomDirection;
    }
                            
    public function eraseCredentials()
    {
        
    }
    
    public function isEqualTo(UserInterface $user) {
        
        if(!$user instanceof Utilisateur)
        {
            return false;
        }
        
        if($this->password !== $user->getPassword())
        {
            return false;
        }
        
        if($this->salt !== $user->getSalt())
        {
            return false;
        }
        
        if($this->username !== $user->getUsername())
        {
            return false;
        }
        
        return true;
    }

    

    /**
     * Set direction
     *
     * @param string $direction
     *
     * @return User
     */
    public function setDirection($direction)
    {
        $this->direction = $direction;

        return $this;
    }

    /**
     * Get direction
     *
     * @return string
     */
    public function getDirection()
    {
        return $this->direction;
    }

    /**
     * Set service
     *
     * @param string $service
     *
     * @return User
     */
    public function setService($service)
    {
        $this->service = $service;

        return $this;
    }

    /**
     * Get service
     *
     * @return string
     */
    public function getService()
    {
        return $this->service;
    }

   
    /**
     * Set derniereConnexion
     *
     * @param string $derniereConnexion
     *
     * @return User
     */
    public function setDerniereConnexion($derniereConnexion)
    {
        $this->derniereConnexion = $derniereConnexion;

        return $this;
    }

    /**
     * Get derniereConnexion
     *
     * @return string
     */
    public function getDerniereConnexion()
    {
        return $this->derniereConnexion;
    }

    /**
     * Add appRole
     *
     * @param \AppBundle\Entity\Role $appRole
     *
     * @return User
     */
    public function addAppRole(\AppBundle\Entity\Role $appRole)
    {
        $this->appRoles[] = $appRole;

        return $this;
    }

    /**
     * Remove appRole
     *
     * @param \AppBundle\Entity\Role $appRole
     */
    public function removeAppRole(\AppBundle\Entity\Role $appRole)
    {
        $this->appRoles->removeElement($appRole);
    }

    /**
     * Get appRoles
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getAppRoles()
    {
        return $this->appRoles;
    }

    /**
     * Set departement
     *
     * @param string $departement
     *
     * @return User
     */
    public function setDepartement($departement)
    {
        $this->departement = $departement;

        return $this;
    }

    /**
     * Get departement
     *
     * @return string
     */
    public function getDepartement()
    {
        return $this->departement;
    }

    /**
     * Set profilStaf
     *
     * @param string $profilStaf
     *
     * @return User
     */
    public function setProfilStaf($profilStaf)
    {
        $this->profilStaf = $profilStaf;

        return $this;
    }

    /**
     * Get profilStaf
     *
     * @return string
     */
    public function getProfilStaf()
    {
        return $this->profilStaf;
    }

    /**
     * Set nature
     *
     * @param string $nature
     *
     * @return User
     */
    public function setNature($nature)
    {
        $this->nature = $nature;

        return $this;
    }

    /**
     * Get nature
     *
     * @return string
     */
    public function getNature()
    {
        return $this->nature;
    }

    
    /**
     * Get contrats
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getContrats()
    {
        return $this->contrats;
    }
}
