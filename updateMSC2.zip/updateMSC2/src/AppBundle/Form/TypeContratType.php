<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use AppBundle\Entity\TypeContrat;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use AppBundle\Form\NiveauWorkflowBaseType;

/**
 * Description of TypeContratType
 *
 * @author ndziePatrick
 */
class TypeContratType extends AbstractType {
    //put your code here
    
    public function buildForm(FormBuilderInterface $builder, array $options)
    {        
        parent::buildForm($builder, $options);
        
        $builder->add('nom');
        $builder->add('description', TextareaType::class);
        $builder->add('template', FileType::class, 
                                 ['required' => false, 
                                  'empty_data' => null]);
        $builder->add('niveaux', CollectionType::class,
                [
                    'entry_type' => NiveauWorkflowBaseType::class,
                    'allow_add' => true
                ]);
    }
    
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array('data_class' => TypeContrat::class, 'csrf_protection' => false));
    }
}
