<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use AppBundle\Entity\Contrat;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;



/**
 * Description of TypeDocumentType
 *
 * @author ndziePatrick
 */
class ContratType extends AbstractType {
    //put your code here
    
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        
    
        $builder->add('preavis', IntegerType::class);
        
        $builder->add('dureeContrat', IntegerType::class);
        
        $builder->add('taciteReconduction');
        
        $builder->add('typeContrat', EntityType::class, array(
            'class' => 'AppBundle:TypeContrat'
        ));
        
        $builder->add('direction', EntityType::class, array(
            'class' => 'AppBundle:Direction'
        ));
        
        $builder->add('cocontractants', EntityType::class,
                [
                    'class' => "AppBundle:Cocontractant",
                    'multiple' => true
                ]);
        $builder->add('documents', CollectionType::class,
                [
                    'entry_type' => DocumentType::class,
                    'allow_add' => true
                ]);
        $builder->add('entiteInitiatrice', ChoiceType::class, array(
            'choices' => array(
                'OCM' => 'OCM',
                'OCMS' => 'OCMS',
                'FONDATION ORANGE' => 'FONDATION ORANGE'
            )
        ));
        $builder->add('modalitesFinancieres', CollectionType::class,
                [
                    'entry_type' => ModaliteFinanciereType::class,
                    'allow_add' => true
                ]);
        $builder->add('fichier', FileType::class, 
                                 ['required' => false, 
                                  'empty_data' => null]);
        
        $builder->add('objet', TextareaType::class);
        
    }
    
    public function configureOptions(OptionsResolver $resolver) 
    {
        
        $resolver->setDefaults(
                array('data_class' => Contrat::class,
                      'csrf_protection' => false));
    }
    
    public function getName()
    {
        return "cocontractantForm";
    }
}
