<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use AppBundle\Entity\Document;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\FileType;


/**
 * Description of TypeDocumentType
 *
 * @author ndziePatrick
 */
class DocumentType extends AbstractType {
    //put your code here
    
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('nom');
        $builder->add('type', EntityType::class, array(
            'class' => 'AppBundle:TypeDocument',
            'choice_label' => 'type'
        ));
        $builder->add('fichier', FileType::class, 
                                 ['required' => false, 
                                  'empty_data' => null]);
        
    }
    
    public function configureOptions(OptionsResolver $resolver) {
        
        $resolver->setDefaults(
                array('data_class' => Document::class,
                      'csrf_protection' => false));
    }
    
    public function getName()
    {
        return "adresseTypeForm";
    }
}
