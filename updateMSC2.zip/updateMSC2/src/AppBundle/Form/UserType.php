<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Form;

use Symfony\Component\Form\FormBuilderInterface;

/**
 * Description of TypeDocumentType
 *
 * @author ndziePatrick
 */
class UserType extends UpdateUserType {
    //put your code here
    
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        parent::buildForm($builder, $options);
        $builder->add('username');
        
    }
        
}
