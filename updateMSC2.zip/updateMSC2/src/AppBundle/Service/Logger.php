<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Service;

/**
 * Description of Logger
 *
 * @author ndziePatrick
 */
class Logger {
    //put your code here
            
    public function writeException($fileLocation, $message)
    {
        date_default_timezone_set("Africa/Douala");
    }
            
            
}
