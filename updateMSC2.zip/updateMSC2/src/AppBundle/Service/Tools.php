<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Service;

use Symfony\Component\HttpFoundation\Request;

/**
 * Description of Tools
 *
 * @author ndziePatrick
 */
class Tools {
    //put your code here
    
    public $CONTROLLERS_EXCEPTIONS_LOCATION = "exceptions/controllers/";
    
    protected $defaultTimeZoneSet;


    public function __construct($default_time_zone_set) {
        
        $this->defaultTimeZoneSet = $default_time_zone_set;
    }
    
    public function writeExceptionMessage($location, $message)
    {
        $fichier = fopen($location, "a+");
        fputs($fichier, print_r($message, true));
        fclose($fichier);
    }
    
    public function writeExceptionFromControllerAction(Request $request, \Exception $ex)
    {
        $this->setDefaultTimeZoneSet();
        $date = date("Y-m-d H:i:s", time());
        
        $params = explode('::', $request->attributes->get('_controller'));
        $actionNameLeft = str_replace("\\", "_", $params[0]);
        $actionNameRight = "_".$params[1];            
        $actionName = $actionNameLeft.$actionNameRight.".txt";
        
        $fileLocation = $this->CONTROLLERS_EXCEPTIONS_LOCATION.$actionName;
        
        $message = $date." : ".$ex->getMessage().PHP_EOL.$ex->getTraceAsString().PHP_EOL;        
        $this->writeExceptionMessage($fileLocation, $message);
    }
    
    public function setDefaultTimeZoneSet()
    {
        date_default_timezone_set($this->defaultTimeZoneSet);
    }
    
    public function getFormErrorMessages(\Symfony\Component\Form\Form $form)
    {
        $errors = [];
        
        /*$fichier = fopen("testFormErrorData.txt", "w+");
            fputs($fichier, print_r($form->getErrors(), true));
            fclose($fichier);*/
        
        
        foreach($form->getErrors() as $key => $error)
        {
            $errors[] = $error->getMessage()."_".$form->getName();
        }
        
        $fichier = fopen("testErrorsTools.txt", "w+");
        fputs($fichier, print_r($errors, true));
        fclose($fichier);
        
       foreach($form->all() as $child)
        {
            if(!$child->isValid())
            {
                $errors[] = $child->getName().">".$this->getFormErrorMessages($child)."_".$child->getName();
            }
        }
              
        
        return $errors;
    }
}
