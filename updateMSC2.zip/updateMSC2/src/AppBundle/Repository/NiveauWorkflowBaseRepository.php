<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;
use AppBundle\Entity\NiveauWorkflowBase;

/**
 * Description of NiveauWorkflowBaseRepository
 *
 * @author ndziePatrick
 */
class NiveauWorkflowBaseRepository extends EntityRepository {
    //put your code here
    
    /**
     * cette fonction permet d'avoir le niveau suivant d'un niveau
     * @param NiveauWorkflowBase $current
     * @return type
     */
    public function getNextNiveau(NiveauWorkflowBase $current)
    {
     return $this->getEntityManager()
              ->createQuery(
                      'select n from AppBundle:NiveauWorkflowBase n '
                      . 'where n.typeContrat = :typeContrat and n.niveau - 1 = :currentLevel')
              ->setParameter("typeContrat", $current->getTypeContrat()->getId())
              ->setParameter("currentLevel", $current->getNiveau());
    }
    
    public function getPreviousNiveau(NiveauWorkflowBase $current)
    {
      return $this->getEntityManager()
              ->createQuery(
                      'select n from AppBundle:NiveauWorkflowBase n '
                      . 'where n.typeContrat = :typeContrat and n.niveau + 1 = :currentLevel')
              ->setParameter("typeContrat", $current->getTypeContrat()->getId())
              ->setParameter("currentLevel", $current->getNiveau());  
    }
    
    public function getMaxNiveau()
    {
        
    }
}
