/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(".btnRemoveRow").bind("click", deleteParent);

$("#btnAddRow").bind("click", function ()
{
    var baseRow = $("#baseRow").html();

    $("#livrablesTable").append("<tr>" + baseRow + "</tr>");
    $(".btnRemoveRow").bind("click", deleteParent);
});

$("#btnAddRowUpdate").bind("click", function ()
{
    var baseRow = $("#baseRow").html();

    $("#livrablesTableUpdate").append("<tr>" + baseRow + "</tr>");
    $(".btnRemoveRow").bind("click", deleteParent);
});

function deleteParent()
{
    var par = $(this).parent().parent();

    //on teste si le parent n'a pas pour id baseRow (dans ce cas on ne le supprime pas    
        par.remove();

    
}

function initUpdateTable(livrables)
{
    var rows = "";

    for (var i = 0; i < livrables.length; i++)
    {
        var newRow = "<tr><td>";

        var select = "<select class='form-control typeItem'>";

        $("#typesLivrablesSrc option").each(function () {

            if ($(this).val() === livrables[i].type.toString())
            {
                select += "<option value='" + $(this).val() + "'selected>" + $(this).text() + "</option>";
            }

            else
            {
                select += "<option value='" + $(this).val() + "'>" + $(this).text() + "</option>";
            }
        });
        
        select += "</select>";
        
        var select2 = "<select class='form-control'>";
        
        $("#prioritesSrc option").each(function () {

            if ($(this).val() === livrables[i].requis.toString())
            {
                select2 += "<option value='" + $(this).val() + "'selected>" + $(this).val() + "</option>";
            }

            else
            {
                select2 += "<option value='" + $(this).val() + "'>" + $(this).val() + "</option>";
            }
        });
        
        select2 += "</select>";
        
        var select3 = "<select class='form-control'>";
        
        $("#prioritesSrc option").each(function () {

            if ($(this).val() === livrables[i].multiple.toString())
            {
                select3 += "<option value='" + $(this).val() + "'selected>" + $(this).val() + "</option>";
            }

            else
            {
                select3 += "<option value='" + $(this).val() + "'>" + $(this).val() + "</option>";
            }
        });
        
        select3 += "</select>";
        
        newRow += select + "</td>";
        newRow += "<td><input type='text' value='" + livrables[i].nom + "' class='form-control'/></td>";
        newRow += "<td>"+select2+"</td><td>"+select3+"</td>";
        newRow += "<td><a href='#nothing' class='btn btn-danger btn-xs btnRemoveRow'><i class='fa fa-trash'></i></a></td></tr>";
        
        rows += newRow;
    }
    
    $("#livrablesTableUpdate tbody").html(rows);
    $(".btnRemoveRow").bind("click", deleteParent);
}

/**
 * cette fonction lit le 
 * tableau des adresses et les retourne sous 
 * forme d'un table d'objet
 * @returns {undefined}
 */
function getLivrables(selector)
{
    var table = new Array();

    $(selector).each(function (row, tr) {
        
        table[row] = {
            'type': $(tr).find('td:eq(0)').find('select').val(),
            'nom': $(tr).find('td:eq(1)').find('input').val(),
            'requis': $(tr).find('td:eq(2)').find('select').val(),
            'multiple': $(tr).find('td:eq(3)').find('select').val()
        };

    });

    // on supprime l'entête
    table.shift();

    return table;
}

$(".updateElement").bind("click", function ()
{
    var id = $(this).parent().parent().find("td:eq(0)").text().trim();
    var nom = $(this).parent().parent().find("td:eq(1)").text().trim();
    var description = $(this).parent().parent().find("td:eq(2)").text().trim();

    $("#updateDescription").val(description);
    $("#updateNom").val(nom);
    $("#updateId").val(id);

    var route = Routing.generate("roles_for_etat", {'id': id});
    var data = {};

    App.executeRequest(data, route, false, function (data) {

        var result = JSON.parse(data);

        if (result.result !== 0)
        {

            var etatRoles = result.data;

            var updateRolesHtml = "";

            $("#roles option").each(function () {

                if ($.inArray(parseInt($(this).val()), etatRoles) !== -1)
                {
                    updateRolesHtml += "<option value='" + $(this).val() + "' selected>" + $(this).text() + "</option>";
                }
                else
                {
                    updateRolesHtml += "<option value='" + $(this).val() + "'>" + $(this).text() + "</option>";
                }
            });

            console.log(updateRolesHtml);

            $("#updateRoles").html(updateRolesHtml);
            $("#updateRoles").select2({});
        }
        else
        {
            console.log("error");
        }
    });
    
    var route2 = Routing.generate("livrables_etat_etat", {'id': id});
    var data = {};

    $("#livrablesTableUpdate").find("tr:eq(1)").remove();
    $("#livrablesTableUpdate").append("<tr><td span='3'>Loading Adresses ...</td></tr>");
    App.executeRequest(data, route2, 'json', function (data) {
        
        console.log(data);
        var result = JSON.parse(data);
        var adresses = result.data;
        
        initUpdateTable(adresses);

    });


});

$(".deleteElement").bind("click", function (e) {

    $("#deleteCharacters").html(App.randomString(8));

    var id = $(this).attr("idElement");

    $("#toDelete").val(id);

});

$("#deleteElementForm").bind("submit", function (e) {

    e.preventDefault();

    //on teste si l'utilisateur a bien saisi les informations requises
    if ($("#deleteCharacters").html() === $("#inputCharacters").val())
    {

        var formData = new FormData(this);

        var idElement = $("#toDelete").val();

        $("#deleteElementRequestLoading").toggle();

        var route = Routing.generate("delete_etat", {'id': idElement});

        App.executeRequest(formData, route, false, function (data) {

            var result = JSON.parse(data);

            if (result.result !== 0)
            {
                $("#deleteElementRequestLoading").toggle();
                $("#deleteElementRequestSuccess").toggle();
                location.reload();
            }
            else
            {
                var errorMessage = result.data;
                var errorHtml = "";
                for (var i = 0, length = errorMessage.length; i < length; i++)
                {
                    errorHtml += "<span>" + errorMessage[i] + "</span><br/>";
                }

                $("#deleteElementRequestLoading").toggle();
                $("#deleteElementRequestError").toggle();
                $("#deleteElementRequestError .formErrorMessage").html(errorHtml);
            }
        });
    }
    else
    {
        $("#deleteElementRequestError").toggle();
        $("#deleteElementRequestError .formErrorMessage").html("<span>Les caractères ne correspondent pas</span>");
    }

});

$("#updateElementForm").bind("submit", function (e) {

    e.preventDefault();

    $("#updateElementRequestLoading").toggle();

    //var formData = new FormData(this);

    var idElement = $("#updateId").val();
    
    var roles = [];
    
    $("#updateRoles option:selected").each(function(){
       roles.push($(this).val()); 
    });
    
    var nom = $("#updateNom").val();
    var description = $("#updateDescription").val();
    
    var livrables = getLivrables("#livrablesTableUpdate tr");
    
    var formData= JSON.stringify(
            {'nom': nom, 'description': description,
             'roles': roles, 'livrables': livrables });


    var route = Routing.generate("update_etat", {'id': idElement});

    App.executeRequest(formData, route, false, function (data) {

        var result = JSON.parse(data);

        if (result.result !== 0)
        {
            $("#updateElementRequestLoading").toggle();
            $("#updateElementRequestSuccess").toggle();
            location.reload();
        }
        else
        {
            var errorMessage = result.data;
            var errorHtml = "";
            for (var i = 0, length = errorMessage.length; i < length; i++)
            {
                errorHtml += "<span>" + errorMessage[i] + "</span><br/>";
            }

            $("#updateElementRequestLoading").toggle();
            $("#updateElementRequestError").toggle("show");
            $("#updateElementRequestError .errorMessage").html(errorHtml);
        }

    });

});

$("#newElementForm").bind("submit", function (e)
{
    e.preventDefault();

    $("#newElementRequestLoading").toggle();
    
    var roles = [];
    
    $("#roles option:selected").each(function(){
       roles.push($(this).val()); 
    });
    
    var nom = $("#nom").val();
    var description = $("#description").val();
    
    var livrables = getLivrables("#livrablesTable tr");
    
    var formData= JSON.stringify(
            {'nom': nom, 'description': description,
             'roles': roles, 'livrables': livrables });

    var route = Routing.generate("new_etat");

    App.executeRequest(formData, route, false, function (data)
    {
        var result = JSON.parse(data);

        if (result.result !== 0)
        {

            $("#newElementRequestLoading").toggle();
            $("#newElementRequestSuccess").toggle();
            location.reload();
        }
        else
        {
            var errorMessage = result.data;
            var errorHtml = "";

            for (var i = 0, length = errorMessage.length; i < length; i++)
            {
                errorHtml += "<span>" + errorMessage[i] + "</span><br/>";
            }

            $("#newElementRequestLoading").toggle();
            $("#newElementRequestError").toggle("show");

            $("#newElementRequestError .errorMessage").html(errorHtml);
        }

    });
});

