/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(".btnRemoveRow").bind("click", deleteParent);

$("#btnAddRow").bind("click", function ()
{
    var baseRow = $("#baseRow").html();

    $("#adressesTable").append("<tr>" + baseRow + "</tr>");
    $(".btnRemoveRow").bind("click", deleteParent);
});

$("#btnAddRowUpdate").bind("click", function ()
{
    var baseRow = $("#baseRow").html();

    $("#adressesTableUpdate").append("<tr>" + baseRow + "</tr>");
    $(".btnRemoveRow").bind("click", deleteParent);
});

function deleteParent()
{
    var par = $(this).parent().parent();

    //on teste si le parent n'a pas pour id baseRow (dans ce cas on ne le supprime pas

    if (par.attr("id") !== "baseRow")
    {
        par.remove();

    }
}

/**
 * cette fonction lit le 
 * tableau des adresses et les retourne sous 
 * forme d'un table d'objet
 * @returns {undefined}
 */
function getAdresses(selector)
{
    var table = new Array();

    $(selector).each(function (row, tr) {

        table[row] = {
            'type': $(tr).find('td:eq(0)').find('select').val(),
            'adresse': $(tr).find('td:eq(1)').find('input').val()
        };

    });

    // on supprime l'entête
    table.shift();

    return table;
}

$(".updateElement").bind("click", function ()
{
    var id = $(this).parent().parent().find("td:eq(0)").text().trim();
    var nom = $(this).parent().parent().find("td:eq(1)").text().trim();
    var description = $(this).parent().parent().find("td:eq(2)").text().trim();

    $("#updateDescription").val(description);
    $("#updateNom").val(nom);
    $("#updateId").val(id);

    var route = Routing.generate("adresses_cocontractant", {'id': id});
    var data = {};

    $("#adressesTableUpdate").find("tr:eq(1)").remove();
    $("#adressesTableUpdate").append("<tr><td span='3'>Loading Adresses ...</td></tr>");
    App.executeRequest(data, route, 'json', function (data) {

        var result = JSON.parse(data);
        var adresses = result.data;
        
        initUpdateTable(adresses);

    });
});

function initUpdateTable(adresses)
{
    var rows = "";

    for (var i = 0; i < adresses.length; i++)
    {
        var newRow = "<tr><td>";

        var select = "<select class='form-control typeItem'>";

        $("#typesAdressesSrc option").each(function () {

            if ($(this).val() === adresses[i].type.toString())
            {
                select += "<option value='" + $(this).val() + "'selected>" + $(this).text() + "</option>";
            }

            else
            {
                select += "<option value='" + $(this).val() + "'>" + $(this).text() + "</option>";
            }
        });
        newRow += select + "</td><td><input type='text' value='" + adresses[i].adresse + "' class='form-control'/></td>";
        newRow += "<td><a href='#nothing' class='btn btn-danger btn-xs btnRemoveRow'><i class='fa fa-trash'></i></a></td></tr>";

        rows += newRow;
    }



    $("#adressesTableUpdate tbody").html(rows);
    $(".btnRemoveRow").bind("click", deleteParent);
}

$(".deleteElement").bind("click", function (e) {

    $("#deleteCharacters").html(App.randomString(8));

    var id = $(this).attr("idElement");

    $("#toDelete").val(id);

});

$("#deleteElementForm").bind("submit", function (e) {

    e.preventDefault();

    //on teste si l'utilisateur a bien saisi les informations requises
    if ($("#deleteCharacters").html() === $("#inputCharacters").val())
    {

        var formData = new FormData(this);

        var idElement = $("#toDelete").val();

        $("#deleteElementRequestLoading").toggle();

        var route = Routing.generate("delete_cocontractant", {'id': idElement});

        App.executeRequest(formData, route, false, function (data) {

            var result = JSON.parse(data);

            if (result.result !== 0)
            {
                $("#deleteElementRequestLoading").toggle();
                $("#deleteElementRequestSuccess").toggle();
                location.reload();
            }
            else
            {
                var errorMessage = result.data;
                var errorHtml = "";
                for (var i = 0, length = errorMessage.length; i < length; i++)
                {
                    errorHtml += "<span>" + errorMessage[i] + "</span><br/>";
                }

                $("#deleteElementRequestLoading").toggle();
                $("#deleteElementRequestError").toggle();
                $("#deleteElementRequestError .formErrorMessage").html(errorHtml);
            }
        });
    }
    else
    {
        $("#deleteElementRequestError").toggle();
        $("#deleteElementRequestError .formErrorMessage").html("<span>Les caractères ne correspondent pas</span>");
    }

});

$("#updateElementForm").bind("submit", function (e) {

    e.preventDefault();

    $("#updateElementRequestLoading").toggle();
    
    var nom = $("#updateNom").val();
    
    var description = $("#updateDescription").val();

    var adresses = getAdresses("#adressesTableUpdate tr");

    var formData = JSON.stringify({'nom': nom, 'description': description, 'adresses': adresses});

    var idElement = $("#updateId").val();

    var route = Routing.generate("update_cocontractant", {'id': idElement});

    App.executeRequest(formData, route, 'json', function (data) {

        var result = JSON.parse(data);

        if (result.result !== 0)
        {
            $("#updateElementRequestLoading").toggle();
            $("#updateElementRequestSuccess").toggle();
            location.reload();
        }
        else
        {
            var errorMessage = result.data;
            var errorHtml = "";
            for (var i = 0, length = errorMessage.length; i < length; i++)
            {
                errorHtml += "<span>" + errorMessage[i] + "</span><br/>";
            }

            $("#updateElementRequestLoading").toggle();
            $("#updateElementRequestError").toggle("show");
            $("#updateElementRequestError .errorMessage").html(errorHtml);
        }

    });

});

$("#newElementForm").bind("submit", function (e)
{
    e.preventDefault();

    $("#newElementRequestLoading").toggle();

    var nom = $("#nom").val();
    var description = $("#description").val();

    var adresses = getAdresses("#adressesTable tr");

    var formData = JSON.stringify({'nom': nom, 'description': description, 'adresses': adresses});

    var route = Routing.generate("new_cocontractant");

    App.executeRequest(formData, route, 'json', function (data)
    {
        var result = JSON.parse(data);
        if (result.result !== 0)
        {

            $("#newElementRequestLoading").toggle();
            $("#newElementRequestSuccess").toggle();
            location.reload();
        }
        else
        {
            var errorMessage = result.data;
            var errorHtml = "";

            for (var i = 0, length = errorMessage.length; i < length; i++)
            {
                errorHtml += "<span>" + errorMessage[i] + "</span><br/>";
            }

            $("#newElementRequestLoading").toggle();
            $("#newElementRequestError").toggle("show");

            $("#newElementRequestError .formErrorMessage").html(errorHtml);
        }

    });
});

