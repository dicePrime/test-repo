/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(".updateElement").bind("click", function ()
{
    var id = $(this).parent().parent().find("td:eq(0)").text().trim();
    var  nom = $(this).parent().parent().find("td:eq(1)").text().trim();

    $("#updateNom").val(nom);
    $("#updateId").val(id);

});

$(".deleteElement").bind("click", function (e) {

    $("#deleteCharacters").html(App.randomString(8));

    var id = $(this).attr("idElement");

    $("#toDelete").val(id);

});

$("#deleteElementForm").bind("submit", function (e) {

    e.preventDefault();

    if ($("#deleteCharacters").html() === $("#inputCharacters").val())
    {
        var formData = new FormData(this);

        var idElement = $("#toDelete").val();

        $("#deleteElementRequestLoading").toggle();

        var route = Routing.generate("delete_direction", {'id': idElement});

        App.executeRequest(formData, route, false, function (data) {

            var result = JSON.parse(data);

            if (result.result !== 0)
            {
                $("#deleteElementRequestLoading").toggle();
                $("#deleteElementRequestSuccess").toggle();
                location.reload();
            }
            else
            {
                var errorMessage = result.data;
                var errorHtml = "";
                for (var i = 0, length = errorMessage.length; i < length; i++)
                {
                    errorHtml += "<span>" + errorMessage[i] + "</span><br/>";
                }

                $("#deleteElementRequestLoading").toggle();
                $("#deleteElementRequestError").toggle();
                $("#deleteElementRequestError .errorMessage").html(errorHtml);
            }
        });
    }
    else
    {
        $("#deleteElementRequestError").toggle();
        $("#deleteElementRequestError .formErrorMessage").html("<span>Les caractères ne correspondent pas</span>");
    }

});

$("#updateElementForm").bind("submit", function (e) {

    e.preventDefault();

    $("#updateElementRequestLoading").toggle();

    var formData = new FormData(this);

    var idElement = $("#updateId").val();

    var route = Routing.generate("update_direction", {'id': idElement});

    App.executeRequest(formData, route, false, function (data) {

        var result = JSON.parse(data);

        if (result.result !== 0)
        {
            $("#updateElementRequestLoading").toggle();
            $("#updateElementRequestSuccess").toggle();
            location.reload();
        }
        else
        {
            var errorMessage = result.data;
            var errorHtml = "";
            for (var i = 0, length = errorMessage.length; i < length; i++)
            {
                errorHtml += "<span>" + errorMessage[i] + "</span><br/>";
            }

            $("#updateElementRequestLoading").toggle();
            $("#updateElementRequestError").toggle("show");
            $("#updateElementRequestError .errorMessage").html(errorHtml);
        }

    });

});

$("#newElementForm").bind("submit", function (e)
{
    e.preventDefault();

    $("#newElementRequestLoading").toggle();

    var formData = new FormData(this);

    var route = Routing.generate("new_direction");

    App.executeRequest(formData, route, false, function (data)
    {
        var result = JSON.parse(data);

        if (result.result !== 0)
        {

            $("#newElementRequestLoading").toggle();
            $("#newElementRequestSuccess").toggle();
            location.reload();
        }
        else
        {
            var errorMessage = result.data;
            var errorHtml = "";

            for (var i = 0, length = errorMessage.length; i < length; i++)
            {
                errorHtml += "<span>" + errorMessage[i] + "</span><br/>";
            }

            $("#newElementRequestLoading").toggle();
            $("#newElementRequestError").toggle("show");

            $("#newElementRequestError .errorMessage").html(errorHtml);
        }

    });
});

