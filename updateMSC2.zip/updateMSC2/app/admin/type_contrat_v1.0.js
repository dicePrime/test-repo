/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(".btnRemoveRow").bind("click", deleteParent);

$("#btnAddRow").bind("click", function ()
{
    var baseRow = $("#baseRow").html();
    $("#niveauxTable tbody").append("<tr>" + baseRow + "</tr>");
    regenerateLevels("#niveauxTable tr");
    $(".btnRemoveRow").bind("click", deleteParent);
});

function regenerateLevels(tableSelector)
{

    $(tableSelector).each(function (row, tr) {

        if (row !== 0)
        {
            $(tr).find('td:eq(0)').text(parseInt(row));
        }


    });
}

$("#btnAddRowUpdate").bind("click", function ()
{
    var baseRow = $("#baseRow").html();

    $("#niveauxTableUpdate").append("<tr>" + baseRow + "</tr>");
    regenerateLevels("#niveauxTableUpdate tr");
    $(".btnRemoveRow").bind("click", deleteParent);
});

function deleteParent()
{
    var par = $(this).parent().parent();

    //on teste si le parent n'a pas pour id baseRow (dans ce cas on ne le supprime pas

    if (par.attr("id") !== "baseRow")
    {
        par.remove();
        regenerateLevels("#niveauxTableUpdate tr");
        regenerateLevels("#niveauxTable tr");

    }
}

/**
 * 
 * @param {type} selector
 * @returns {getNiveaux.table|Array}
 */
function getNiveaux(selector)
{
    var table = new Array();

    $(selector).each(function (row, tr) {

        table[row] = {
            'niveau': parseInt($(tr).find('td:eq(0)').text()),
            'etat': parseInt($(tr).find('td:eq(1)').find('select').val())
        };

    });

    // on supprime l'entête
    table.shift();

    return table;
}

$(".updateElement").bind("click", function ()
{
    var id = $(this).parent().parent().find("td:eq(0)").text().trim();
    var nom = $(this).parent().parent().find("td:eq(1)").text().trim();
    var description = $(this).parent().parent().find("td:eq(2)").text().trim();
    var oldModel = $(this).parent().parent().find("td:eq(3)").html();

    $("#updateDescription").val(description);
    $("#updateNom").val(nom);
    $("#updateId").val(id);
    $("#oldModele").html(oldModel);

    var route = Routing.generate("niveaux_type_contrat", {'id': id});
    var data = {};

    $("#niveauxTableUpdate").find("tr:eq(1)").remove();
    $("#niveauxTableUpdate").append("<tr><td span='3'>Loading levels ...</td></tr>");
    App.executeRequest(data, route, 'json', function (data) {
        
        var result = JSON.parse(data);
        var niveaux = result.data;
        initUpdateTable(niveaux);

    });
});

function initUpdateTable(niveaux)
{
    var rows = "";

    for (var i = 0; i < niveaux.length; i++)
    {
        var newRow = "<tr><td>";

        var select = "<select class='form-control typeItem'>";

        $("#etatsSrc option").each(function () {

            if ($(this).val() === niveaux[i].etat.toString())
            {
                select += "<option value='" + $(this).val() + "'selected>" + $(this).text() + "</option>";
            }

            else
            {
                select += "<option value='" + $(this).val() + "'>" + $(this).text() + "</option>";
            }
        });
        newRow += niveaux[i].niveau+"</td>";
        newRow += "<td>"+select + "</td>";        
        newRow += "<td><a href='#nothing' class='btn btn-danger btn-xs btnRemoveRow'><i class='fa fa-trash'></i></a></td></tr>";

        rows += newRow;
    }



    $("#niveauxTableUpdate tbody").html(rows);
    $(".btnRemoveRow").bind("click", deleteParent);
}

$(".deleteElement").bind("click", function (e) {

    $("#deleteCharacters").html(App.randomString(8));

    var id = $(this).attr("idElement");

    $("#toDelete").val(id);

});

$("#deleteElementForm").bind("submit", function (e) {

    e.preventDefault();

    //on teste si l'utilisateur a bien saisi les informations requises
    if ($("#deleteCharacters").html() === $("#inputCharacters").val())
    {

        var formData = new FormData(this);

        var idElement = $("#toDelete").val();

        $("#deleteElementRequestLoading").toggle();

        var route = Routing.generate("delete_type_contrat", {'id': idElement});

        App.executeRequest(formData, route, false, function (data) {

            var result = JSON.parse(data);

            if (result.result !== 0)
            {
                $("#deleteElementRequestLoading").toggle();
                $("#deleteElementRequestSuccess").toggle();
                location.reload();
            }
            else
            {
                var errorMessage = result.data;
                var errorHtml = "";
                for (var i = 0, length = errorMessage.length; i < length; i++)
                {
                    errorHtml += "<span>" + errorMessage[i] + "</span><br/>";
                }

                $("#deleteElementRequestLoading").toggle();
                $("#deleteElementRequestError").toggle();
                $("#deleteElementRequestError .formErrorMessage").html(errorHtml);
            }
        });
    }
    else
    {
        $("#deleteElementRequestError").toggle();
        $("#deleteElementRequestError .formErrorMessage").html("<span>Les caractères ne correspondent pas</span>");
    }

});

$("#updateElementForm").bind("submit", function (e) {

    e.preventDefault();

    $("#updateElementRequestLoading").toggle();
    var modele = $("#updateModele").get(0).files[0];
    
    var nom = $("#updateNom").val();
    var description = $("#updateDescription").val();
    var niveaux = getNiveaux("#niveauxTableUpdate tr");
    
    var formData = new FormData();
    
    formData.append('nom', nom);
    formData.append('description', description);
    formData.append('niveaux', JSON.stringify(niveaux));
    if(modele !== undefined)
    {
        formData.append('template', modele);
    }
                    
    var idElement = $("#updateId").val();
    var route = Routing.generate("update_type_contrat", {'id': idElement});

    App.executeRequest(formData, route, false, function (data) {

        var result = JSON.parse(data);

        if (result.result !== 0)
        {
            $("#updateElementRequestLoading").toggle();
            $("#updateElementRequestSuccess").toggle();
            location.reload();
        }
        else
        {
            var errorMessage = result.data;
            var errorHtml = "";
            for (var i = 0, length = errorMessage.length; i < length; i++)
            {
                errorHtml += "<span>" + errorMessage[i] + "</span><br/>";
            }

            $("#updateElementRequestLoading").toggle();
            $("#updateElementRequestError").toggle("show");
            $("#updateElementRequestError .errorMessage").html(errorHtml);
        }

    });

});

$("#newElementForm").bind("submit", function (e)
{
    e.preventDefault();

    $("#newElementRequestLoading").toggle();

    var nom = $("#nom").val();
    var description = $("#description").val();
    //le fichier
    var modele = $("#modele").get(0).files[0];
    var niveaux = getNiveaux("#niveauxTable tr");
    var formData = new FormData();

    formData.append('nom', nom);
    formData.append('description', description);
    formData.append('niveaux', JSON.stringify(niveaux));
    formData.append('template', modele);

    //var formData = JSON.stringify({'nom': nom, 'description': description, 'adresses': adresses});

    var route = Routing.generate("new_type_contrat");

    App.executeRequest(formData, route, false, function (data)
    {
        var result = JSON.parse(data);
        if (result.result !== 0)
        {

            $("#newElementRequestLoading").toggle();
            $("#newElementRequestSuccess").toggle();
            location.reload();
        }
        else
        {
            var errorMessage = result.data;
            var errorHtml = "";

            for (var i = 0, length = errorMessage.length; i < length; i++)
            {
                errorHtml += "<span>" + errorMessage[i] + "</span><br/>";
            }

            $("#newElementRequestLoading").toggle();
            $("#newElementRequestError").toggle("show");

            $("#newElementRequestError .formErrorMessage").html(errorHtml);
        }

    });
});

