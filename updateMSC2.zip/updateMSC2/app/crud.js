/**
 * 
 * ce module est celui responsable de la création d'un nouvel élément
 * En gros il soumet le formulaire à un controleur
 */

var App = App || {};

App.lastResponseData = {};

/**
 * cette fonction prend en paramètre un nombre entier et une chaine de charactères 
 * et retourne une chaine de caractères de longueur length constitué de length elements
 * pris au hasard parmis chars
 * si chars n'est pas précisé les charactères sont les caractères de l'alphabet.
 * @param {type} length
 * @param {type} chars
 * @returns {String}
 */
App.randomString = function(length, chars)
{
    var result = '';
    var chaine;
    if(chars === undefined)
    {
        chaine = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    }
    else
    {
        chaine = chars;
    }
    
    for(var i = length; i > 0; --i)
    {
        result += chaine[Math.floor(Math.random() * chaine.length)];
    }
    
    return result;
};

App.executeRequest = function(formData, route, contentType, callBack)
    {
        $.ajax({
            url: route,
            type: 'POST',
            data: formData,
            contentType: contentType,
            cache: false,
            processData: false}
            )
            .done(function(data)
            {                
                callBack(data);               
            })
            .fail(function(){
                var result = {result:0, data:["Erreur côté serveur veuillez contacter l'administrateur"]};
                callBack(result);
            });       
            
    };







