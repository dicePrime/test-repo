/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(".btnRemoveRow").bind("click", deleteParent);

$("#btnAddRow").bind("click", function ()
{
    var baseRow = $("#baseRow").html();

    $("#adressesTable").append("<tr>" + baseRow + "</tr>");
    $(".btnRemoveRow").bind("click", deleteParent);
});

function deleteParent()
{
    var par = $(this).parent().parent();

    //on teste si le parent n'a pas pour id baseRow (dans ce cas on ne le supprime pas

    if (par.attr("id") !== "baseRow")
    {
        par.remove();

    }
}

/**
 * cette fonction lit le 
 * tableau des adresses et les retourne sous 
 * forme d'un table d'objet
 * @returns {undefined}
 */
function getAdresses(selector)
{
    var table = new Array();

    $(selector).each(function (row, tr) {

        table[row] = {
            'type': $(tr).find('td:eq(0)').find('select').val(),
            'adresse': $(tr).find('td:eq(1)').find('input').val()
        };

    });

    // on supprime l'entête
    table.shift();

    return table;
}

$("#newElementForm").bind("submit", function (e)
{
    e.preventDefault();

    $("#newElementRequestLoading").toggle();

    var nom = $("#nom").val();
    var description = $("#description").val();

    var adresses = getAdresses("#adressesTable tr");

    var formData = JSON.stringify({'nom': nom, 'description': description, 'adresses': adresses});

    var route = Routing.generate("create_return_new_cocontractant");

    App.executeRequest(formData, route, 'json', function (data)
    {
        var result = JSON.parse(data);
        if (result.result !== 0)
        {
            //console.log(result);
            
            var id = result.data.id;
            var nom = result.data.nom;
            
            var newOption = "<option value='"+id+"' selected>"+nom+"</option>";
            
            $("#cocontractants").append(newOption);
            
            $("#cocontractants").select2({});
            
            $("#newElementRequestLoading").toggle();
            $("#newElementRequestSuccess").toggle();
            $("#myModal").modal('toggle');
        }
        else
        {
            var errorMessage = result.data;
            var errorHtml = "";

            for (var i = 0, length = errorMessage.length; i < length; i++)
            {
                errorHtml += "<span>" + errorMessage[i] + "</span><br/>";
            }

            $("#newElementRequestLoading").toggle();
            $("#newElementRequestError").toggle("show");

            $("#newElementRequestError .formErrorMessage").html(errorHtml);
        }

    });
});

