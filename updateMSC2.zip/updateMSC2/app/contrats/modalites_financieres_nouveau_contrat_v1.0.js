/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(".btnRemoveRowModalites").bind("click", deleteParentModalites);

$("#btnAddRowModalites").bind("click", function ()
{
    var baseRow = $("#baseRowModalites").html();

    $("#modalitesTable").append("<tr>" + baseRow + "</tr>");
    $(".btnRemoveRowModalites").bind("click", deleteParentModalites);
});

function deleteParentModalites()
{
    var par = $(this).parent().parent();

    //on teste si le parent n'a pas pour id baseRow (dans ce cas on ne le supprime pas

    if (par.attr("id") !== "baseRowModalites")
    {
        par.remove();

    }
}

$(".btnRemoveRowDocuments").bind("click", deleteParentDocuments);

$("#btnAddDocuments").bind("click", function ()
{
    var baseRow = $("#baseRowDocuments").html();

    $("#documentsTable").append("<tr>" + baseRow + "</tr>");
    $(".btnRemoveRowDocuments").bind("click", deleteParentDocuments);
});

function deleteParentDocuments()
{
    var par = $(this).parent().parent();

    //on teste si le parent n'a pas pour id baseRow (dans ce cas on ne le supprime pas

    if (par.attr("id") !== "baseRowDocuments")
    {
        par.remove();

    }
}

/**
 * cette fonction lit le 
 * tableau des adresses et les retourne sous 
 * forme d'un table d'objet
 * @returns {undefined}
 */


