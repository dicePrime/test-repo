
$("#typeContrat").bind("change", changeTemplateLocation);
$("#btnEnregistrer").bind("click", function(e){
    e.preventDefault();
    saveContrat();
});

$("#btnSoumettre").bind("click", function(e){
    e.preventDefault();
    submitContrat();
});

changeTemplateLocation();

function changeTemplateLocation()
{
   var selectedId = $("#typeContrat").val();
   
   $("#paths option").each(function()
   {
       if($(this).val() === selectedId)
       {
           var ref = $(this).text();
           $("#templateUrl").attr("href", ref);
       }
   });
}

function saveContrat()
{
    $("#newElementRequestLoading").toggle();    

    //var formData = JSON.stringify({'nom': nom, 'description': description, 'adresses': adresses});

    var route = Routing.generate("add_contrat");
    
    var formData = getNewContratFormData();
    

   App.executeRequest(formData, route, false, function (data)
    {
        var result = JSON.parse(data);
        if (result.result !== 0)
        {

            $("#newElementRequestLoading").toggle();
            $("#newElementRequestSuccess").toggle();
            
            var redirectRoute = Routing.generate("contrats_utilisateur");
            window.location = redirectRoute;
        }
        else
        {
            var errorMessage = result.data;
            var errorHtml = "";

            for (var i = 0, length = errorMessage.length; i < length; i++)
            {
                errorHtml += "<span>" + errorMessage[i] + "</span><br/>";
            }

            $("#newElementRequestLoading").toggle();
            $("#newElementRequestError").toggle("show");

            $("#newElementRequestError .formErrorMessage").html(errorHtml);
        }

    }); 
}

function submitContrat()
{
    
}

function getDocuments(selector)
{
    var table = new Array();
    
    $(selector).each(function (row, tr){
        if(row !== 0)
        {
            table[row] = {
                'type': parseInt($(tr).find('td:eq(0)').find('select').val()),
                'nom': $(tr).find('td:eq(1)').find('input').val(),
                'fichier':  $(tr).find('td:eq(2)').find('input').get(0).files[0]
                };                            
        }
    });
       
    console.log(table);
    
    table.shift();
    
    return table;
}

function getModalites(selector)
{
    var table = new Array();

    $(selector).each(function (row, tr) {

        table[row] = {
            'nom': $(tr).find('td:eq(0)').find('input').val(),
            'description': $(tr).find('td:eq(1)').find('textarea').val(),
            'montant': parseInt($(tr).find('td:eq(2)').find('input').val())
        };

    });

    // on supprime l'entête
    table.shift();

    return table;
}

function getNewContratFormData()
{
    var entiteInitiatrice = $("#entiteInitiatrice").val();
    var direction = $("#directionInitiatrice").val();
    var typeContrat = parseInt($("#typeContrat").val());
    var objet = $("#objetContrat").val();
    var dureeContrat = $("#dureeContrat").val();
    var preavis = $("#preavis").val();    //le fichier
    var contrat = $("#contrat").get(0).files[0];    
    var cocontractants = [];    
    var modalitesFinancieres = getModalites("#modalitesTable tr");
    var taciteReconduction = $("#taciteReconduction").val();
    
    $("#cocontractants option:selected").each(function()
    {
       cocontractants.push(parseInt($(this).val())); 
    });
    
    var documents = getDocuments("#documentsTable tr"); 
    
    var formData = new FormData();
       
    formData.append('entiteInitiatrice', entiteInitiatrice);
    formData.append('direction', direction);
    formData.append('typeContrat', typeContrat);
    formData.append('taciteReconduction', taciteReconduction);
    formData.append('objet', objet);
    formData.append('dureeContrat', dureeContrat);
    formData.append('preavis', preavis);
    formData.append('contrat', contrat);
    formData.append('cocontractants', JSON.stringify(cocontractants));
    formData.append('modalitesFinancieres', JSON.stringify(modalitesFinancieres));
    
    var documentsSansFichier = [];
    
    for(var i = 0; i < documents.length; i++)
    {
        documentsSansFichier.push({
                'type': documents[i].type,
                'nom': documents[i].nom}
                );
        formData.append("document[]", documents[i].fichier);
    }
    formData.append('documents', JSON.stringify(documentsSansFichier));
        
    return formData;

}

$("#newContratForm").bind("submit", function (e)
{
    e.preventDefault();

   
});
