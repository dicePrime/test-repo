
loadDocumentsContrat();
loadModalitesFinancieres();
loadHistoriquesActions();
loadInformationsContrat();
loadCocontractants();



function loadCocontractants()
{
    var idElement = $("#elementId").val();
    var route = Routing.generate("get_cocontractants_contrat", {'id': idElement });
    var data = {};   
  
   App.executeRequest(data, route, false, function (data)
    {
        var result = JSON.parse(data);
        if (result.result !== 0)
        {
           var rows = result.data;
           
           var htmlRows = [];
           
           for(var i = 0; i< rows.length; i++)
           {
               htmlRows.push("<tr><td>"+(i+1)+"</td><td>"+rows[i].nom+"</td><td></tr>");
           }
           $("#synCocontractantsTable tbody").html("");
           
           for(var j = 0; j < htmlRows.length; j++)
           {
               $("#synCocntractantsTable tbody").append(htmlRows[j]);
           }
           
           $("#cocontractants option").each(function () {
               
               
            for(var i = 0; i < rows.length; i++)
            {
                if(parseInt($(this).val()) === rows[i].id)
                {
                    $(this).prop("selected", true);
                    break;
                }
            }
                      
        });
        $("#cocontractants").select2({});

        }
        else
        {
            
        }

    }); 
}

function loadInformationsContrat()
{
   var idElement = $("#elementId").val();
    var route = Routing.generate("get_identification_contrat", {'id': idElement });    
    var data = {};
  
   App.executeRequest(data, route, false, function (data)
    {
        var result = JSON.parse(data);
        if (result.result !== 0)
        {
           var rows = result.data;
           
           var htmlRows = "<caption>Identification du contrat</caption>";             
           htmlRows = "<tr><th>Code</th><td>"+rows.codeChrono+"</td></tr>";
           htmlRows += "<tr><th>Date d'ouverture</th><td>"+rows.dateOuverture+"</td></tr>";
           htmlRows += "<tr><th>Entité initiatrice</th><td>"+rows.entiteInitiatrice+"</td></tr>"; 
           htmlRows += "<tr><th>Direction</th><td>"+rows.direction+"</td></tr>";
           htmlRows += "<tr><th>Initiateur</th><td>"+rows.nomInitiateur+"</td></tr>";
           htmlRows += "<tr><th>Date d'ouverture</th><td><a href='/msc2/web/uploads/contrats/"+idElement+"/"+rows.document+"' target='_blank' class='orangeText'>"+rows.document+"</td></tr>";
           htmlRows += "<tr><th>Statut</th><td>"+rows.statut+"</td></tr>";
           
           $("#oldContratUrl").attr("href", "/msc2/web/uploads/contrats/"+idElement+"/"+rows.document);
           
           $("#infoContratTable").html("");
           
           $("#infoContratTable").append(htmlRows);
           

        }
        else
        {
            
        }

    });  
}

function loadHistoriquesActions()
{
    var idElement = $("#elementId").val();
    var route = Routing.generate("get_historiques_actions_contrat", {'id': idElement });    
    var data = {};
  
   App.executeRequest(data, route, false, function (data)
    {
        var result = JSON.parse(data);
        if (result.result !== 0)
        {
           var rows = result.data;
           
           console.log(rows);
           
           var htmlRows = [];
                      
           
           for(var i = 0; i< rows.length; i++)
           {
               
               htmlRows.push("<li><i class='fa fa-circle text-primary'></i>"+
                             "<div class='timeline-item'><span class='time'><i class='fa fa-clock-o'></i>"+rows[i].dateAction+"</span><br>"
                             +"<h3 class='timeline-header'><a href='#'>"+rows[i].nomUser+"</a></h3>"
                             +"<div class='timeline-body'><strong>"+rows[i].nom+"</strong><br/>"+rows[i].description+"</div></div></li>");
           }
           $("#historiquesActionsList").html("");
           
           for(var j = 0; j < htmlRows.length; j++)
           {
               $("#historiquesActionsList").append(htmlRows[j]);
           }

        }
        else
        {
            
        }

    }); 
}

/**
 * cette fonction permet de recharger
 * les modalités financières
 * @returns {undefined}
 */
function loadModalitesFinancieres()
{
    var idElement = $("#elementId").val();

    var route = Routing.generate("get_modalites_financieres_contrat", {'id': idElement });
    
    var data = {};  
  
   /**
    * On execute la requête et dans le callback,
    * on met à jour les tableaux
    */
   App.executeRequest(data, route, false, function (data)
    {
        var result = JSON.parse(data);
        if (result.result !== 0)
        {
           var rows = result.data;
           
           var htmlRows = [];
           
           for(var i = 0; i< rows.length; i++)
           {
               htmlRows.push("<tr><td>"+rows[i].nom+"</td><td>"+rows[i].description+"</td><td>"+rows[i].montant+"</a></td></tr>");
           }
           $("#synModalitesTable tbody").html("");
           
           for(var j = 0; j < htmlRows.length; j++)
           {
               $("#synModalitesTable tbody").append(htmlRows[j]);
           }
           
           var baseRowModalites = "<tr id='baseRowModalites'><td><input type='text' class='form-control'/></td>";
               baseRowModalites+= "<td><textarea class='form-control'></textarea></td>";
               baseRowModalites+= "<td><input type='number' class='form-control'/></td>";
               baseRowModalites+= "<td><a class='btn btn-danger btn-xs btnRemoveRowModalites'><i class='fa fa-trash'></i></a></td></tr>";
               
           $("#modalitesTable tbody").html("");
           
           var newRows = [];
           
           for(var i = 0; i < rows.length; i++)
           {
               var tmpRow = "<tr><td><input type'text' value='"+rows[i].nom+"' class='form-control'/></td>";
                   tmpRow+= "<td><textarea class='form-control'>"+rows[i].description+"</textarea></td>";
                   tmpRow+= "<td><input type='number' value='"+rows[i].montant+"' class='form-control'/></td>";
                   tmpRow+= "<td><a class='btn btn-danger btn-xs btnRemoveRowModalites'><i class='fa fa-trash'></i></a></td></tr>";
               newRows.push(tmpRow);
           }
           
           for(var j = 0; j < newRows.length; j++)
           {
               $("#modalitesTable tbody").append(newRows[j]);
           }
           
           $("#modalitesTable tbody").append(baseRowModalites);
           
           $(".btnRemoveRowModalites").bind("click", deleteParentModalites);
        }
        else
        {
            
        }

    }); 
}

function loadDocumentsContrat()
{          

    //var formData = JSON.stringify({'nom': nom, 'description': description, 'adresses': adresses});
    
    var idElement = $("#elementId").val();

    var route = Routing.generate("get_documents_contrat", {'id': idElement });
    
    var data = {};
    
  

   App.executeRequest(data, route, false, function (data)
    {
        var result = JSON.parse(data);
        if (result.result !== 0)
        {
           
           var rows = result.data;
           
           var htmlRows = [];
           
           for(var i = 0; i< rows.length; i++)
           {
               htmlRows.push("<tr><td>"+rows[i].type+"</td><td>"+rows[i].nom+"</td><td><a href='/msc2/web/uploads/documents/"+rows[i].id+"/"+rows[i].chemin+"' class='orangeText'>"+rows[i].chemin+"</a></td></tr>");
           }
           $("#synDocumentsTable tbody").html("");
           
           for(var j = 0; j < htmlRows.length; j++)
           {
               $("#synDocumentsTable tbody").append(htmlRows[j]);
           }
           
           
           var oldDocumentsTableRows = [];
           
           for(var i = 0; i< rows.length; i++)
           {
               oldDocumentsTableRows.push("<tr><td>"+rows[i].id+"</td><td>"+rows[i].type+"</td><td>"+rows[i].nom+"</td><td><a href='/msc2/web/uploads/documents/"+rows[i].id+"/"+rows[i].chemin+"' class='orangeText'>"+rows[i].chemin+"</a></td><td><input type='checkbox' name='deleteDocument'></td></tr>");
           }
           
           $("#oldDocumentsTable tbody").html("");
                       
            for(var j = 0; j < htmlRows.length; j++)
           {
               $("#oldDocumentsTable tbody").append(oldDocumentsTableRows[j]);
           }          
        }
        else
        {
            
        }

    }); 
}